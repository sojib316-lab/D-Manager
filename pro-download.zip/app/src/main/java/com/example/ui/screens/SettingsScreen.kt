package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ThemeMode
import com.example.data.preferences.DownloaderSettings
import com.example.engine.Formatters
import com.example.ui.theme.MonoMetricStyle

@Composable
fun SettingsScreen(
    settings: DownloaderSettings,
    appStorageBytes: Long,
    hasNotificationPermission: Boolean,
    onRequestNotificationPermission: () -> Unit,
    onDefaultThreadsChange: (Int) -> Unit,
    onMaxConcurrentChange: (Int) -> Unit,
    onSpeedLimitChange: (Int) -> Unit,
    onWifiOnlyChange: (Boolean) -> Unit,
    onAutoRetryChange: (Boolean) -> Unit,
    onThemeModeChange: (ThemeMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
                item(key = "notif_permission_banner") {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.NotificationsActive,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Enable Download Notifications",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "Show live background progress and completion alerts.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                )
                            }
                            Button(onClick = onRequestNotificationPermission) {
                                Text("Allow")
                            }
                        }
                    }
                }
            }

            item(key = "threads_setting") {
                SettingSectionCard(
                    title = "Default Threads Per File",
                    subtitle = "Splits range-capable downloads into parallel connections",
                    icon = Icons.Rounded.Bolt
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1, 2, 4, 8).forEach { count ->
                            FilterChip(
                                selected = settings.defaultThreads == count,
                                onClick = { onDefaultThreadsChange(count) },
                                label = { Text("${count}T") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_threads_$count")
                            )
                        }
                    }
                }
            }

            item(key = "concurrent_setting") {
                SettingSectionCard(
                    title = "Max Concurrent Downloads",
                    subtitle = "Active queue slots running simultaneously",
                    icon = Icons.Rounded.Speed
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        (1..5).forEach { count ->
                            FilterChip(
                                selected = settings.maxConcurrentDownloads == count,
                                onClick = { onMaxConcurrentChange(count) },
                                label = { Text("$count") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            item(key = "speed_limit_setting") {
                val options = listOf(
                    0 to "Unlimited",
                    512 to "512 KB/s",
                    1024 to "1 MB/s",
                    2048 to "2 MB/s",
                    5120 to "5 MB/s",
                    10240 to "10 MB/s"
                )
                SettingSectionCard(
                    title = "Global Speed Limit",
                    subtitle = "Throttle bandwidth across active transfers",
                    icon = Icons.Rounded.Speed
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        options.chunked(3).forEach { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowItems.forEach { (kbps, label) ->
                                    FilterChip(
                                        selected = settings.speedLimitKbps == kbps,
                                        onClick = { onSpeedLimitChange(kbps) },
                                        label = { Text(label) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item(key = "network_toggles") {
                SettingSectionCard(
                    title = "Network & Recovery",
                    subtitle = "Control metered data usage and connection drops",
                    icon = Icons.Rounded.Wifi
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Wi-Fi Only Downloads", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Pause automatically when not on unmetered Wi-Fi",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = settings.wifiOnly,
                                onCheckedChange = onWifiOnlyChange,
                                modifier = Modifier.testTag("settings_wifi_only_switch")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Auto-Retry Failed Transfers", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Retry up to 3 times on transient network errors",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = settings.autoRetry,
                                onCheckedChange = onAutoRetryChange
                            )
                        }
                    }
                }
            }

            item(key = "theme_setting") {
                SettingSectionCard(
                    title = "Appearance",
                    subtitle = "Choose light, dark, or follow system theme",
                    icon = Icons.Rounded.Palette
                ) {
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        ThemeMode.entries.forEachIndexed { idx, mode ->
                            SegmentedButton(
                                selected = settings.themeMode == mode,
                                onClick = { onThemeModeChange(mode) },
                                shape = SegmentedButtonDefaults.itemShape(
                                    index = idx,
                                    count = ThemeMode.entries.size
                                )
                            ) {
                                Text(mode.label)
                            }
                        }
                    }
                }
            }

            item(key = "storage_summary") {
                SettingSectionCard(
                    title = "Storage & Export Path",
                    subtitle = "Completed files are saved to Downloads/ProDownload",
                    icon = Icons.Rounded.Storage
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Active part cache & app storage",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = Formatters.formatBytes(appStorageBytes),
                            style = MonoMetricStyle,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSectionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Column {
                    Text(text = title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            content()
        }
    }
}
