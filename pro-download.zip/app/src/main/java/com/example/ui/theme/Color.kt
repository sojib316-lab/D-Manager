package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Precision Jetstream Cyan & Obsidian Slate palette
val CyanPrimaryLight = Color(0xFF00677D)
val OnCyanPrimaryLight = Color(0xFFFFFFFF)
val CyanContainerLight = Color(0xFFB3EBFF)
val OnCyanContainerLight = Color(0xFF001F28)

val SlateSecondaryLight = Color(0xFF4B626B)
val OnSlateSecondaryLight = Color(0xFFFFFFFF)
val SlateContainerLight = Color(0xFFCEE7F1)
val OnSlateContainerLight = Color(0xFF061E26)

val EmeraldTertiaryLight = Color(0xFF0E6B4B)
val OnEmeraldTertiaryLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFA0F4CE)
val OnEmeraldContainerLight = Color(0xFF002114)

val BackgroundLight = Color(0xFFF5F8FA)
val OnBackgroundLight = Color(0xFF141C20)
val SurfaceLight = Color(0xFFFBFDFF)
val OnSurfaceLight = Color(0xFF141C20)
val SurfaceVariantLight = Color(0xFFDBE4E8)
val OnSurfaceVariantLight = Color(0xFF3F484D)
val OutlineLight = Color(0xFF6F797D)
val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)

// Dark theme tokens
val CyanPrimaryDark = Color(0xFF4FD8F7)
val OnCyanPrimaryDark = Color(0xFF003642)
val CyanContainerDark = Color(0xFF004E5F)
val OnCyanContainerDark = Color(0xFFB3EBFF)

val SlateSecondaryDark = Color(0xFFB3CAD5)
val OnSlateSecondaryDark = Color(0xFF1D333C)
val SlateContainerDark = Color(0xFF344A53)
val OnSlateContainerDark = Color(0xFFCEE7F1)

val EmeraldTertiaryDark = Color(0xFF6FE3B3)
val OnEmeraldTertiaryDark = Color(0xFF003825)
val EmeraldContainerDark = Color(0xFF005138)
val OnEmeraldContainerDark = Color(0xFFA0F4CE)

val BackgroundDark = Color(0xFF0A111A)
val OnBackgroundDark = Color(0xFFE0E6EB)
val SurfaceDark = Color(0xFF0F1824)
val OnSurfaceDark = Color(0xFFE0E6EB)
val SurfaceVariantDark = Color(0xFF1B2736)
val OnSurfaceVariantDark = Color(0xFFBFC8CD)
val OutlineDark = Color(0xFF899297)
val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)
val ErrorContainerDark = Color(0xFF93000A)
val OnErrorContainerDark = Color(0xFFFFDAD6)

// Semantic status accents
val StatusActiveCyan = Color(0xFF00B8D9)
val StatusCompletedEmerald = Color(0xFF10B981)
val StatusPausedAmber = Color(0xFFF59E0B)
val StatusQueuedViolet = Color(0xFF8B5CF6)
val StatusFailedCoral = Color(0xFFEF4444)
