package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTaskWithSegments
import com.example.data.model.FileCategory
import com.example.data.model.LinkProbeResult
import com.example.data.model.ThemeMode
import com.example.data.preferences.DownloaderSettings
import com.example.data.repository.DownloadRepository
import com.example.engine.Formatters
import com.example.engine.LiveTransferStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class DownloadFilter(val label: String) {
    ALL("All"),
    ACTIVE("Active"),
    QUEUED("Queued"),
    PAUSED("Paused"),
    COMPLETED("Completed"),
    FAILED("Failed")
}

sealed interface ProbeUiState {
    data object Idle : ProbeUiState
    data object Loading : ProbeUiState
    data class Ready(val result: LinkProbeResult) : ProbeUiState
    data class Error(val message: String) : ProbeUiState
}

data class DownloadsUiState(
    val allTasks: List<DownloadTaskWithSegments> = emptyList(),
    val filteredTasks: List<DownloadTaskWithSegments> = emptyList(),
    val completedTasks: List<DownloadTaskWithSegments> = emptyList(),
    val filteredVaultTasks: List<DownloadTaskWithSegments> = emptyList(),
    val liveStats: Map<Long, LiveTransferStats> = emptyMap(),
    val aggregateSpeedBps: Long = 0L,
    val speedHistory: List<Float> = List(24) { 0f },
    val activeFilter: DownloadFilter = DownloadFilter.ALL,
    val vaultCategoryFilter: FileCategory? = null,
    val searchQuery: String = "",
    val settings: DownloaderSettings = DownloaderSettings(),
    val activeCount: Int = 0,
    val queuedCount: Int = 0,
    val completedCount: Int = 0,
    val totalVaultBytes: Long = 0L
)

class MainViewModel(private val repository: DownloadRepository) : ViewModel() {

    private val _activeFilter = MutableStateFlow(DownloadFilter.ALL)
    private val _vaultCategory = MutableStateFlow<FileCategory?>(null)
    private val _searchQuery = MutableStateFlow("")
    private val _probeState = MutableStateFlow<ProbeUiState>(ProbeUiState.Idle)
    val probeState: StateFlow<ProbeUiState> = _probeState.asStateFlow()

    private val _showAddSheet = MutableStateFlow(false)
    val showAddSheet: StateFlow<Boolean> = _showAddSheet.asStateFlow()

    private val _prefilledUrl = MutableStateFlow("")
    val prefilledUrl: StateFlow<String> = _prefilledUrl.asStateFlow()

    private val _inspectorTaskId = MutableStateFlow<Long?>(null)

    private val _appStorageBytes = MutableStateFlow(0L)
    val appStorageBytes: StateFlow<Long> = _appStorageBytes.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private val filterParamsFlow = combine(
        _activeFilter,
        _vaultCategory,
        _searchQuery
    ) { filter, category, query ->
        Triple(filter, category, query)
    }

    private val telemetryFlow = combine(
        repository.liveStats,
        repository.aggregateSpeedBps,
        repository.speedHistory
    ) { live, speed, history ->
        Triple(live, speed, history)
    }

    val uiState: StateFlow<DownloadsUiState> = combine(
        repository.allDownloads,
        repository.settingsFlow,
        filterParamsFlow,
        telemetryFlow
    ) { allTasks, settings, (filter, vaultCategory, query), (liveStats, aggSpeed, history) ->
        val normalizedQuery = query.trim().lowercase()

        val filteredDownloads = allTasks.filter { item ->
            val matchesFilter = when (filter) {
                DownloadFilter.ALL -> true
                DownloadFilter.ACTIVE -> item.task.downloadStatus.isRunning
                DownloadFilter.QUEUED -> item.task.downloadStatus == DownloadStatus.QUEUED
                DownloadFilter.PAUSED -> item.task.downloadStatus == DownloadStatus.PAUSED
                DownloadFilter.COMPLETED -> item.task.downloadStatus == DownloadStatus.COMPLETED
                DownloadFilter.FAILED -> item.task.downloadStatus == DownloadStatus.FAILED
            }
            val matchesQuery = normalizedQuery.isEmpty() ||
                item.task.fileName.lowercase().contains(normalizedQuery) ||
                item.task.url.lowercase().contains(normalizedQuery)
            matchesFilter && matchesQuery
        }

        val completed = allTasks.filter { it.task.downloadStatus == DownloadStatus.COMPLETED }
        val filteredVault = completed.filter { item ->
            val matchesCat = vaultCategory == null || item.task.fileCategory == vaultCategory
            val matchesQuery = normalizedQuery.isEmpty() ||
                item.task.fileName.lowercase().contains(normalizedQuery)
            matchesCat && matchesQuery
        }

        DownloadsUiState(
            allTasks = allTasks,
            filteredTasks = filteredDownloads,
            completedTasks = completed,
            filteredVaultTasks = filteredVault,
            liveStats = liveStats,
            aggregateSpeedBps = aggSpeed,
            speedHistory = history,
            activeFilter = filter,
            vaultCategoryFilter = vaultCategory,
            searchQuery = query,
            settings = settings,
            activeCount = allTasks.count { it.task.downloadStatus.isRunning },
            queuedCount = allTasks.count { it.task.downloadStatus == DownloadStatus.QUEUED },
            completedCount = completed.size,
            totalVaultBytes = completed.sumOf {
                if (it.task.totalBytes > 0L) it.task.totalBytes else it.task.downloadedBytes
            }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DownloadsUiState()
    )

    val inspectorTask: StateFlow<DownloadTaskWithSegments?> = combine(
        uiState,
        _inspectorTaskId
    ) { state, selectedId ->
        if (selectedId == null) null else state.allTasks.firstOrNull { it.task.id == selectedId }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    init {
        refreshStorageUsage()
    }

    fun refreshStorageUsage() {
        viewModelScope.launch(Dispatchers.IO) {
            _appStorageBytes.value = repository.computeAppStorageBytes()
        }
    }

    fun setFilter(filter: DownloadFilter) {
        _activeFilter.value = filter
    }

    fun setVaultCategory(category: FileCategory?) {
        _vaultCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openAddSheet(initialUrl: String = "") {
        _prefilledUrl.value = initialUrl
        _probeState.value = ProbeUiState.Idle
        _showAddSheet.value = true
        if (Formatters.isValidHttpUrl(initialUrl)) {
            probeUrl(initialUrl)
        }
    }

    fun dismissAddSheet() {
        _showAddSheet.value = false
        _probeState.value = ProbeUiState.Idle
    }

    fun openInspector(downloadId: Long) {
        _inspectorTaskId.value = downloadId
    }

    fun dismissInspector() {
        _inspectorTaskId.value = null
    }

    fun probeUrl(rawUrl: String) {
        val url = rawUrl.trim()
        if (!Formatters.isValidHttpUrl(url)) {
            _probeState.value = ProbeUiState.Error("Enter a valid http:// or https:// URL")
            return
        }
        viewModelScope.launch {
            _probeState.value = ProbeUiState.Loading
            val result = repository.probeLink(url)
            _probeState.value = if (result.isReachable) {
                ProbeUiState.Ready(result)
            } else {
                ProbeUiState.Error(result.errorMessage ?: "Unable to reach URL")
            }
        }
    }

    fun resetProbe() {
        _probeState.value = ProbeUiState.Idle
    }

    fun enqueueSingle(
        rawUrl: String,
        customFileName: String?,
        threads: Int,
        wifiOnly: Boolean,
        startImmediately: Boolean,
        preProbed: LinkProbeResult?
    ) {
        val url = rawUrl.trim()
        if (!Formatters.isValidHttpUrl(url)) {
            _events.tryEmit("Please enter a valid http:// or https:// URL")
            return
        }
        viewModelScope.launch {
            repository.enqueueDownload(
                url = url,
                customFileName = customFileName,
                threads = threads,
                wifiOnly = wifiOnly,
                startImmediately = startImmediately,
                preProbed = preProbed
            )
            _showAddSheet.value = false
            _probeState.value = ProbeUiState.Idle
            _events.tryEmit(if (startImmediately) "Download queued" else "Saved as paused")
            refreshStorageUsage()
        }
    }

    fun enqueueBatch(
        batchInput: String,
        threads: Int,
        wifiOnly: Boolean,
        startImmediately: Boolean
    ) {
        val urls = Formatters.extractUrlsFromText(batchInput)
        if (urls.isEmpty()) {
            _events.tryEmit("No valid http:// or https:// links found")
            return
        }
        viewModelScope.launch {
            urls.forEach { url ->
                repository.enqueueDownload(
                    url = url,
                    customFileName = null,
                    threads = threads,
                    wifiOnly = wifiOnly,
                    startImmediately = startImmediately,
                    preProbed = null
                )
            }
            _showAddSheet.value = false
            _probeState.value = ProbeUiState.Idle
            _events.tryEmit("Added ${urls.size} downloads to queue")
            refreshStorageUsage()
        }
    }

    fun pause(id: Long) {
        viewModelScope.launch { repository.pause(id) }
    }

    fun resume(id: Long) {
        viewModelScope.launch { repository.resume(id) }
    }

    fun retry(id: Long) {
        viewModelScope.launch { repository.retry(id) }
    }

    fun pauseAll() {
        viewModelScope.launch {
            repository.pauseAll()
            _events.tryEmit("All active downloads paused")
        }
    }

    fun resumeAll() {
        viewModelScope.launch {
            repository.resumeAll()
            _events.tryEmit("Resuming queued downloads")
        }
    }

    fun delete(id: Long, deleteFile: Boolean) {
        viewModelScope.launch {
            if (_inspectorTaskId.value == id) {
                _inspectorTaskId.value = null
            }
            repository.delete(id, deleteFile)
            refreshStorageUsage()
            _events.tryEmit("Download removed")
        }
    }

    fun clearCompletedHistory() {
        viewModelScope.launch {
            repository.clearCompleted()
            refreshStorageUsage()
            _events.tryEmit("Cleared completed list")
        }
    }

    fun buildOpenIntent(item: DownloadTaskWithSegments) =
        repository.buildOpenIntent(item.task.exportedUri, item.task.partFilePath, item.task.mimeType)

    fun buildShareIntent(item: DownloadTaskWithSegments) =
        repository.buildShareIntent(
            item.task.exportedUri,
            item.task.partFilePath,
            item.task.mimeType,
            item.task.fileName
        )

    fun setDefaultThreads(threads: Int) {
        viewModelScope.launch { repository.setDefaultThreads(threads) }
    }

    fun setMaxConcurrent(maxConcurrent: Int) {
        viewModelScope.launch { repository.setMaxConcurrent(maxConcurrent) }
    }

    fun setSpeedLimitKbps(kbps: Int) {
        viewModelScope.launch { repository.setSpeedLimitKbps(kbps) }
    }

    fun setWifiOnly(enabled: Boolean) {
        viewModelScope.launch { repository.setWifiOnly(enabled) }
    }

    fun setAutoRetry(enabled: Boolean) {
        viewModelScope.launch { repository.setAutoRetry(enabled) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    class Factory(private val repository: DownloadRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
                return MainViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
