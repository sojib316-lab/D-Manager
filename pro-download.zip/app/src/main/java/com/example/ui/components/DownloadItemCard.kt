package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.SegmentEntity
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTaskWithSegments
import com.example.engine.Formatters
import com.example.engine.LiveTransferStats
import com.example.ui.theme.MonoMetricStyle
import java.net.URI

@Composable
fun DownloadItemCard(
    item: DownloadTaskWithSegments,
    liveStats: LiveTransferStats?,
    onCardClick: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRetry: () -> Unit,
    onOpen: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val task = item.task
    val status = task.downloadStatus
    val category = task.fileCategory
    val statusColor = status.accentColor()
    val categoryColor = category.accentColor()

    val downloaded = liveStats?.downloadedBytes ?: task.downloadedBytes
    val total = liveStats?.totalBytes ?: task.totalBytes
    val speedBps = liveStats?.speedBytesPerSec ?: 0L
    val etaSeconds = liveStats?.etaSeconds ?: -1L
    val percent = if (status == DownloadStatus.COMPLETED) {
        100
    } else if (total > 0L) {
        ((downloaded * 100L) / total).toInt().coerceIn(0, 100)
    } else {
        0
    }

    val host = runCatching { URI(task.url).host }.getOrNull() ?: "Direct link"

    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("download_card_${task.id}")
            .clickable(onClick = onCardClick),
        shape = MaterialTheme.shapes.medium,
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(categoryColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = category.icon(),
                        contentDescription = category.label,
                        tint = categoryColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = task.fileName,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = statusColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = status.displayLabel(),
                                style = MaterialTheme.typography.labelSmall,
                                color = statusColor,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        if (task.threadCount > 1) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "${task.threadCount}T",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = host,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Primary Action Button (48dp target)
                when (status) {
                    DownloadStatus.DOWNLOADING, DownloadStatus.CONNECTING, DownloadStatus.QUEUED -> {
                        IconButton(
                            onClick = onPause,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("pause_button_${task.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Pause,
                                contentDescription = "Pause download",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    DownloadStatus.PAUSED -> {
                        IconButton(
                            onClick = onResume,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("resume_button_${task.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = "Resume download",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    DownloadStatus.FAILED, DownloadStatus.CANCELED -> {
                        IconButton(
                            onClick = onRetry,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("retry_button_${task.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Retry download",
                                tint = statusColor
                            )
                        }
                    }
                    DownloadStatus.COMPLETED -> {
                        IconButton(
                            onClick = onOpen,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("open_button_${task.id}")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                                contentDescription = "Open downloaded file",
                                tint = statusColor
                            )
                        }
                    }
                }
            }

            // ADM-style Multi-Segment Progress Bar
            if (status == DownloadStatus.CONNECTING || (status == DownloadStatus.DOWNLOADING && total <= 0L)) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = statusColor,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            } else {
                SegmentedProgressBar(
                    segments = item.sortedSegments,
                    fallbackFraction = if (status == DownloadStatus.COMPLETED) 1f else if (total > 0L) (downloaded.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f,
                    fillColor = statusColor,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            // Metrics Footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val sizeLabel = if (total > 0L) {
                    "${Formatters.formatBytes(downloaded)} / ${Formatters.formatBytes(total)}"
                } else {
                    Formatters.formatBytes(downloaded)
                }
                Text(
                    text = sizeLabel,
                    style = MonoMetricStyle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (status == DownloadStatus.DOWNLOADING && speedBps > 0L) {
                        Text(
                            text = Formatters.formatSpeed(speedBps),
                            style = MonoMetricStyle,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (etaSeconds >= 0L) {
                            Text(
                                text = "ETA ${Formatters.formatEta(etaSeconds)}",
                                style = MonoMetricStyle,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else if (total > 0L) {
                        Text(
                            text = "$percent%",
                            style = MonoMetricStyle,
                            color = statusColor
                        )
                    }

                    if (status != DownloadStatus.DOWNLOADING && status != DownloadStatus.CONNECTING) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "Delete download",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .size(18.dp)
                                .clickable(onClick = onDelete)
                        )
                    }
                }
            }

            if (!task.errorMessage.isNullOrBlank() && (status == DownloadStatus.FAILED || status == DownloadStatus.PAUSED)) {
                Text(
                    text = task.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun SegmentedProgressBar(
    segments: List<SegmentEntity>,
    fallbackFraction: Float,
    fillColor: Color,
    trackColor: Color,
    modifier: Modifier = Modifier
) {
    if (segments.size <= 1) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(7.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(trackColor)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fallbackFraction.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .background(fillColor)
            )
        }
    } else {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .height(7.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            segments.forEach { segment ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(trackColor)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(segment.progressFraction)
                            .fillMaxHeight()
                            .background(fillColor)
                    )
                }
            }
        }
    }
}
