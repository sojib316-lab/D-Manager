package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.DownloadTaskWithSegments
import com.example.ui.components.DownloadItemCard
import com.example.ui.components.TelemetryHeader
import com.example.ui.viewmodel.DownloadFilter
import com.example.ui.viewmodel.DownloadsUiState

@Composable
fun DownloadsScreen(
    state: DownloadsUiState,
    showSearch: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onToggleSearch: () -> Unit,
    onSelectFilter: (DownloadFilter) -> Unit,
    onPauseAll: () -> Unit,
    onResumeAll: () -> Unit,
    onAddClick: () -> Unit,
    onInspect: (DownloadTaskWithSegments) -> Unit,
    onPause: (Long) -> Unit,
    onResume: (Long) -> Unit,
    onRetry: (Long) -> Unit,
    onOpen: (DownloadTaskWithSegments) -> Unit,
    onDelete: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (showSearch) {
                item(key = "search_bar") {
                    OutlinedTextField(
                        value = state.searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search filename or URL…") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = {
                                onSearchQueryChange("")
                                onToggleSearch()
                            }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Close search")
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_downloads_field")
                    )
                }
            }

            item(key = "telemetry_header") {
                TelemetryHeader(
                    aggregateSpeedBps = state.aggregateSpeedBps,
                    speedHistory = state.speedHistory,
                    activeCount = state.activeCount,
                    queuedCount = state.queuedCount,
                    completedCount = state.completedCount,
                    speedLimitKbps = state.settings.speedLimitKbps,
                    onPauseAll = onPauseAll,
                    onResumeAll = onResumeAll
                )
            }

            item(key = "filter_chips") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DownloadFilter.entries.forEach { filter ->
                        FilterChip(
                            selected = state.activeFilter == filter,
                            onClick = { onSelectFilter(filter) },
                            label = { Text(filter.label) },
                            modifier = Modifier.testTag("filter_chip_${filter.name.lowercase()}")
                        )
                    }
                }
            }

            if (state.filteredTasks.isEmpty()) {
                item(key = "empty_state") {
                    EmptyDownloadsState(
                        isFiltered = state.activeFilter != DownloadFilter.ALL || state.searchQuery.isNotBlank(),
                        onAddClick = onAddClick
                    )
                }
            } else {
                items(
                    items = state.filteredTasks,
                    key = { it.task.id }
                ) { item ->
                    DownloadItemCard(
                        item = item,
                        liveStats = state.liveStats[item.task.id],
                        onCardClick = { onInspect(item) },
                        onPause = { onPause(item.task.id) },
                        onResume = { onResume(item.task.id) },
                        onRetry = { onRetry(item.task.id) },
                        onOpen = { onOpen(item) },
                        onDelete = { onDelete(item.task.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyDownloadsState(
    isFiltered: Boolean,
    onAddClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 28.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_empty_downloads_1794872792289),
            contentDescription = "No downloads in queue",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth(0.78f)
                .height(175.dp)
                .clip(RoundedCornerShape(20.dp))
        )

        Text(
            text = if (isFiltered) "No matching downloads" else "Ready for high-speed transfers",
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )

        Text(
            text = if (isFiltered) {
                "Try switching filters or clearing your search query."
            } else {
                "Paste any HTTP/HTTPS link or share from your browser to accelerate with multi-threaded segments."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        if (!isFiltered) {
            Spacer(modifier = Modifier.height(4.dp))
            Button(
                onClick = onAddClick,
                modifier = Modifier.testTag("empty_add_download_button")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Download")
            }
        }
    }
}
