package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
object DownloadsRoute

@Serializable
object VaultRoute

@Serializable
object SettingsRoute
