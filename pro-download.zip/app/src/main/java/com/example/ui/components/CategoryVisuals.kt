package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.data.model.DownloadStatus
import com.example.data.model.FileCategory
import com.example.ui.theme.StatusActiveCyan
import com.example.ui.theme.StatusCompletedEmerald
import com.example.ui.theme.StatusFailedCoral
import com.example.ui.theme.StatusPausedAmber
import com.example.ui.theme.StatusQueuedViolet

fun FileCategory.icon(): ImageVector = when (this) {
    FileCategory.VIDEO -> Icons.Rounded.Movie
    FileCategory.AUDIO -> Icons.Rounded.AudioFile
    FileCategory.ARCHIVE -> Icons.Rounded.FolderZip
    FileCategory.DOCUMENT -> Icons.Rounded.Description
    FileCategory.APP -> Icons.Rounded.Android
    FileCategory.IMAGE -> Icons.Rounded.Image
    FileCategory.OTHER -> Icons.AutoMirrored.Rounded.InsertDriveFile
}

fun FileCategory.accentColor(): Color = when (this) {
    FileCategory.VIDEO -> Color(0xFF00B8D9)
    FileCategory.AUDIO -> Color(0xFF8B5CF6)
    FileCategory.ARCHIVE -> Color(0xFFF59E0B)
    FileCategory.DOCUMENT -> Color(0xFF3B82F6)
    FileCategory.APP -> Color(0xFF10B981)
    FileCategory.IMAGE -> Color(0xFFEC4899)
    FileCategory.OTHER -> Color(0xFF64748B)
}

@Composable
fun DownloadStatus.accentColor(): Color = when (this) {
    DownloadStatus.DOWNLOADING, DownloadStatus.CONNECTING -> StatusActiveCyan
    DownloadStatus.COMPLETED -> StatusCompletedEmerald
    DownloadStatus.PAUSED -> StatusPausedAmber
    DownloadStatus.QUEUED -> StatusQueuedViolet
    DownloadStatus.FAILED, DownloadStatus.CANCELED -> StatusFailedCoral
}

fun DownloadStatus.displayLabel(): String = when (this) {
    DownloadStatus.QUEUED -> "Queued"
    DownloadStatus.CONNECTING -> "Connecting"
    DownloadStatus.DOWNLOADING -> "Downloading"
    DownloadStatus.PAUSED -> "Paused"
    DownloadStatus.COMPLETED -> "Completed"
    DownloadStatus.FAILED -> "Failed"
    DownloadStatus.CANCELED -> "Canceled"
}
