package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.LinkProbeResult
import com.example.engine.Formatters
import com.example.ui.theme.MonoMetricStyle
import com.example.ui.theme.StatusCompletedEmerald
import com.example.ui.theme.StatusPausedAmber
import com.example.ui.viewmodel.ProbeUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDownloadSheet(
    initialUrl: String,
    defaultThreads: Int,
    defaultWifiOnly: Boolean,
    probeState: ProbeUiState,
    onProbeUrl: (String) -> Unit,
    onResetProbe: () -> Unit,
    onEnqueueSingle: (url: String, customFileName: String?, threads: Int, wifiOnly: Boolean, startNow: Boolean, preProbed: LinkProbeResult?) -> Unit,
    onEnqueueBatch: (batchText: String, threads: Int, wifiOnly: Boolean, startNow: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val clipboard = LocalClipboardManager.current

    var isBatchMode by remember { mutableStateOf(false) }
    var urlInput by remember(initialUrl) { mutableStateOf(initialUrl) }
    var batchInput by remember { mutableStateOf("") }
    var customFileName by remember { mutableStateOf("") }
    var selectedThreads by remember(defaultThreads) { mutableIntStateOf(defaultThreads) }
    var wifiOnly by remember(defaultWifiOnly) { mutableStateOf(defaultWifiOnly) }

    val probedResult = (probeState as? ProbeUiState.Ready)?.result

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "New Download",
                    style = MaterialTheme.typography.headlineSmall
                )

                SingleChoiceSegmentedButtonRow {
                    SegmentedButton(
                        selected = !isBatchMode,
                        onClick = { isBatchMode = false },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) {
                        Text("Single")
                    }
                    SegmentedButton(
                        selected = isBatchMode,
                        onClick = { isBatchMode = true },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                    ) {
                        Text("Batch")
                    }
                }
            }

            if (!isBatchMode) {
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = {
                        urlInput = it
                        onResetProbe()
                    },
                    label = { Text("Download URL (http/https)") },
                    placeholder = { Text("https://example.com/archive.zip") },
                    singleLine = true,
                    leadingIcon = {
                        Icon(imageVector = Icons.Rounded.Link, contentDescription = null)
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                val clip = clipboard.getText()?.text.orEmpty().trim()
                                if (clip.isNotBlank()) {
                                    urlInput = clip
                                    if (Formatters.isValidHttpUrl(clip)) {
                                        onProbeUrl(clip)
                                    }
                                }
                            },
                            modifier = Modifier.testTag("paste_url_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ContentPaste,
                                contentDescription = "Paste URL from clipboard"
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("url_input_field")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { onProbeUrl(urlInput) },
                        enabled = urlInput.isNotBlank() && probeState !is ProbeUiState.Loading,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("inspect_link_button")
                    ) {
                        if (probeState is ProbeUiState.Loading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Inspecting…")
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Inspect Link")
                        }
                    }
                }

                AnimatedVisibility(visible = probeState is ProbeUiState.Ready || probeState is ProbeUiState.Error) {
                    when (probeState) {
                        is ProbeUiState.Ready -> {
                            val res = probeState.result
                            Surface(
                                shape = MaterialTheme.shapes.medium,
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.CheckCircle,
                                            contentDescription = null,
                                            tint = StatusCompletedEmerald,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = res.fileName,
                                            style = MaterialTheme.typography.titleSmall,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Size: ${Formatters.formatBytes(res.totalBytes)}",
                                            style = MonoMetricStyle,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = if (res.supportsRanges) "Multi-Thread Ready" else "Single Stream",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (res.supportsRanges) StatusCompletedEmerald else StatusPausedAmber
                                        )
                                    }
                                    Text(
                                        text = "Type: ${res.mimeType}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        is ProbeUiState.Error -> {
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = MaterialTheme.colorScheme.errorContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = probeState.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                        else -> Unit
                    }
                }

                OutlinedTextField(
                    value = customFileName,
                    onValueChange = { customFileName = it },
                    label = { Text("Save as (optional)") },
                    placeholder = { Text(probedResult?.fileName ?: "Auto-detect filename") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_filename_field")
                )
            } else {
                OutlinedTextField(
                    value = batchInput,
                    onValueChange = { batchInput = it },
                    label = { Text("Paste multiple URLs or text containing links") },
                    placeholder = { Text("https://example.com/file1.zip\nhttps://example.com/file2.mp4") },
                    minLines = 4,
                    maxLines = 7,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("batch_urls_field")
                )
                val detectedCount = remember(batchInput) {
                    Formatters.extractUrlsFromText(batchInput).size
                }
                Text(
                    text = "$detectedCount valid link(s) detected",
                    style = MonoMetricStyle,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Thread count selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Bolt,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Parallel Threads",
                        style = MaterialTheme.typography.titleSmall
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 2, 4, 8).forEach { count ->
                        FilterChip(
                            selected = selectedThreads == count,
                            onClick = { selectedThreads = count },
                            label = { Text("${count}T") },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Download on Wi-Fi only",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "Avoid metered mobile data",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = wifiOnly,
                    onCheckedChange = { wifiOnly = it }
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        if (isBatchMode) {
                            onEnqueueBatch(batchInput, selectedThreads, wifiOnly, false)
                        } else {
                            onEnqueueSingle(
                                urlInput,
                                customFileName.takeIf { it.isNotBlank() },
                                selectedThreads,
                                wifiOnly,
                                false,
                                probedResult
                            )
                        }
                    },
                    enabled = if (isBatchMode) Formatters.extractUrlsFromText(batchInput).isNotEmpty() else Formatters.isValidHttpUrl(urlInput),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Save Paused")
                }

                Button(
                    onClick = {
                        if (isBatchMode) {
                            onEnqueueBatch(batchInput, selectedThreads, wifiOnly, true)
                        } else {
                            onEnqueueSingle(
                                urlInput,
                                customFileName.takeIf { it.isNotBlank() },
                                selectedThreads,
                                wifiOnly,
                                true,
                                probedResult
                            )
                        }
                    },
                    enabled = if (isBatchMode) Formatters.extractUrlsFromText(batchInput).isNotEmpty() else Formatters.isValidHttpUrl(urlInput),
                    modifier = Modifier
                        .weight(1.3f)
                        .testTag("start_download_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Download,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Start Download")
                }
            }
        }
    }
}
