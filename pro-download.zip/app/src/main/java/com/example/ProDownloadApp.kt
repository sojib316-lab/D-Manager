package com.example

import android.app.Application
import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadDao
import com.example.data.preferences.SettingsDataStore
import com.example.data.repository.DownloadRepository
import com.example.engine.DownloadEngine
import com.example.engine.HttpLinkProber
import com.example.engine.StorageExporter
import com.example.service.NotificationHelper
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val database: AppDatabase = AppDatabase.getInstance(appContext)
    val downloadDao: DownloadDao = database.downloadDao()
    val settingsDataStore: SettingsDataStore = SettingsDataStore(appContext)

    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    val linkProber: HttpLinkProber = HttpLinkProber(okHttpClient)
    val storageExporter: StorageExporter = StorageExporter(appContext)
    val notificationHelper: NotificationHelper = NotificationHelper(appContext).apply {
        ensureChannels()
    }

    val downloadEngine: DownloadEngine = DownloadEngine(
        context = appContext,
        dao = downloadDao,
        settingsDataStore = settingsDataStore,
        okHttpClient = okHttpClient,
        linkProber = linkProber,
        storageExporter = storageExporter,
        notificationHelper = notificationHelper
    )

    val repository: DownloadRepository = DownloadRepository(
        dao = downloadDao,
        linkProber = linkProber,
        downloadEngine = downloadEngine,
        settingsDataStore = settingsDataStore,
        storageExporter = storageExporter
    )
}

class ProDownloadApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
