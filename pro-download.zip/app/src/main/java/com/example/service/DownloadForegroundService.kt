package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.ProDownloadApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class DownloadForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var monitorJob: Job? = null
    private lateinit var notificationHelper: NotificationHelper

    override fun onCreate() {
        super.onCreate()
        notificationHelper = NotificationHelper(this)
        notificationHelper.ensureChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val container = (application as ProDownloadApp).container
        if (intent?.action == ACTION_PAUSE_ALL) {
            serviceScope.launch {
                container.downloadEngine.pauseAll()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            return START_NOT_STICKY
        }

        val initialNotification = notificationHelper.buildForegroundNotification(
            activeCount = 1,
            aggregateSpeedBps = 0L,
            overallPercent = -1,
            currentFileName = null
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NotificationHelper.FOREGROUND_NOTIFICATION_ID,
                initialNotification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NotificationHelper.FOREGROUND_NOTIFICATION_ID, initialNotification)
        }

        startTelemetryLoop()
        return START_STICKY
    }

    private fun startTelemetryLoop() {
        if (monitorJob?.isActive == true) return
        val container = (application as ProDownloadApp).container
        monitorJob = serviceScope.launch {
            while (isActive) {
                val stats = container.downloadEngine.liveStats.value
                val activeCount = stats.size
                if (activeCount == 0 && container.downloadDao.getRunningCount() == 0) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    break
                }

                val totalSpeed = stats.values.sumOf { it.speedBytesPerSec }
                val knownTotals = stats.values.filter { it.totalBytes > 0L }
                val overallPercent = if (knownTotals.isNotEmpty()) {
                    val sumDownloaded = knownTotals.sumOf { it.downloadedBytes }
                    val sumTotal = knownTotals.sumOf { it.totalBytes }.coerceAtLeast(1L)
                    ((sumDownloaded * 100L) / sumTotal).toInt().coerceIn(0, 100)
                } else {
                    -1
                }
                val firstName = stats.values.firstOrNull()?.fileName

                if (notificationHelper.hasNotificationPermission()) {
                    val notification = notificationHelper.buildForegroundNotification(
                        activeCount = activeCount.coerceAtLeast(1),
                        aggregateSpeedBps = totalSpeed,
                        overallPercent = overallPercent,
                        currentFileName = firstName
                    )
                    runCatching {
                        NotificationManagerCompat.from(this@DownloadForegroundService)
                            .notify(NotificationHelper.FOREGROUND_NOTIFICATION_ID, notification)
                    }
                }
                delay(800L)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.prodownloader.app.action.START_SERVICE"
        const val ACTION_PAUSE_ALL = "com.prodownloader.app.action.PAUSE_ALL"

        fun start(context: Context) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_START
            }
            runCatching {
                ContextCompat.startForegroundService(context, intent)
            }
        }
    }
}
