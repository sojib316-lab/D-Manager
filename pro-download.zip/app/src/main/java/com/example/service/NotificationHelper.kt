package com.example.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.engine.Formatters

class NotificationHelper(private val context: Context) {

    fun ensureChannels() {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val activeChannel = NotificationChannel(
            CHANNEL_ACTIVE,
            context.getString(R.string.notification_channel_downloads_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = context.getString(R.string.notification_channel_downloads_desc)
            setShowBadge(false)
        }

        val completedChannel = NotificationChannel(
            CHANNEL_EVENTS,
            context.getString(R.string.notification_channel_completed_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.notification_channel_completed_desc)
        }

        manager.createNotificationChannel(activeChannel)
        manager.createNotificationChannel(completedChannel)
    }

    fun buildForegroundNotification(
        activeCount: Int,
        aggregateSpeedBps: Long,
        overallPercent: Int,
        currentFileName: String?
    ): Notification {
        val openAppIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseAllIntent = PendingIntent.getService(
            context,
            1,
            Intent(context, DownloadForegroundService::class.java).apply {
                action = DownloadForegroundService.ACTION_PAUSE_ALL
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (activeCount <= 1 && !currentFileName.isNullOrBlank()) {
            currentFileName
        } else {
            "Downloading $activeCount files"
        }
        val speedText = Formatters.formatSpeed(aggregateSpeedBps)
        val contentText = if (overallPercent in 0..100) {
            "$overallPercent% • $speedText"
        } else {
            "Streaming • $speedText"
        }

        return NotificationCompat.Builder(context, CHANNEL_ACTIVE)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setProgress(100, overallPercent.coerceIn(0, 100), overallPercent < 0)
            .setContentIntent(openAppIntent)
            .addAction(
                android.R.drawable.ic_media_pause,
                context.getString(R.string.action_pause_all),
                pauseAllIntent
            )
            .build()
    }

    fun notifyCompleted(downloadId: Long, fileName: String, totalBytes: Long) {
        if (!hasNotificationPermission()) return
        val openAppIntent = PendingIntent.getActivity(
            context,
            downloadId.toInt(),
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val sizeStr = if (totalBytes > 0L) Formatters.formatBytes(totalBytes) else "Finished"
        val notification = NotificationCompat.Builder(context, CHANNEL_EVENTS)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Download complete")
            .setContentText("$fileName ($sizeStr)")
            .setAutoCancel(true)
            .setContentIntent(openAppIntent)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(
                EVENT_NOTIFICATION_BASE + (downloadId % 10000).toInt(),
                notification
            )
        }
    }

    fun notifyFailed(downloadId: Long, fileName: String, error: String) {
        if (!hasNotificationPermission()) return
        val openAppIntent = PendingIntent.getActivity(
            context,
            downloadId.toInt(),
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_EVENTS)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("Download failed: $fileName")
            .setContentText(error)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(
                EVENT_NOTIFICATION_BASE + (downloadId % 10000).toInt(),
                notification
            )
        }
    }

    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    companion object {
        const val CHANNEL_ACTIVE = "downloads_active"
        const val CHANNEL_EVENTS = "downloads_events"
        const val FOREGROUND_NOTIFICATION_ID = 4101
        private const val EVENT_NOTIFICATION_BASE = 5000
    }
}
