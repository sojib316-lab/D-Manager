package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.DownloadTaskWithSegments
import com.example.engine.Formatters
import com.example.ui.components.AddDownloadSheet
import com.example.ui.components.DownloadInspectorSheet
import com.example.ui.navigation.DownloadsRoute
import com.example.ui.navigation.SettingsRoute
import com.example.ui.navigation.VaultRoute
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VaultScreen
import com.example.ui.theme.ProDownloaderTheme
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ProbeUiState
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        MainViewModel.Factory((application as ProDownloadApp).container.repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            ProDownloaderTheme(themeMode = uiState.settings.themeMode) {
                ProDownloadRoot(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            val firstUrl = Formatters.extractUrlsFromText(sharedText).firstOrNull() ?: sharedText.trim()
            if (firstUrl.isNotBlank()) {
                viewModel.openAddSheet(firstUrl)
            }
        }
    }
}

private enum class TopDestination(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    DOWNLOADS(R.string.nav_downloads, Icons.Rounded.Download, Icons.Outlined.Download),
    VAULT(R.string.nav_vault, Icons.Rounded.Folder, Icons.Outlined.Folder),
    SETTINGS(R.string.nav_settings, Icons.Rounded.Settings, Icons.Outlined.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProDownloadRoot(viewModel: MainViewModel) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val probeState by viewModel.probeState.collectAsStateWithLifecycle()
    val showAddSheet by viewModel.showAddSheet.collectAsStateWithLifecycle()
    val prefilledUrl by viewModel.prefilledUrl.collectAsStateWithLifecycle()
    val inspectorTask by viewModel.inspectorTask.collectAsStateWithLifecycle()
    val appStorageBytes by viewModel.appStorageBytes.collectAsStateWithLifecycle()

    var showSearch by remember { mutableStateOf(false) }

    var hasNotificationPermission by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val activeTab = when {
        currentDestination?.hasRoute<VaultRoute>() == true -> TopDestination.VAULT
        currentDestination?.hasRoute<SettingsRoute>() == true -> TopDestination.SETTINGS
        else -> TopDestination.DOWNLOADS
    }

    fun navigateTo(dest: TopDestination) {
        val route: Any = when (dest) {
            TopDestination.DOWNLOADS -> DownloadsRoute
            TopDestination.VAULT -> VaultRoute
            TopDestination.SETTINGS -> SettingsRoute
        }
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun openDownloadedFile(item: DownloadTaskWithSegments) {
        val intent = viewModel.buildOpenIntent(item)
        if (intent != null) {
            runCatching { context.startActivity(intent) }.onFailure {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("No app installed to open this file type")
                }
            }
        } else {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Downloaded file is no longer available")
            }
        }
    }

    fun shareDownloadedFile(item: DownloadTaskWithSegments) {
        val intent = viewModel.buildShareIntent(item)
        if (intent != null) {
            context.startActivity(Intent.createChooser(intent, "Share ${item.task.fileName}"))
        } else {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Unable to locate file for sharing")
            }
        }
    }

    fun ensureNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = when (activeTab) {
                                TopDestination.DOWNLOADS -> stringResource(R.string.app_name)
                                TopDestination.VAULT -> stringResource(R.string.nav_vault)
                                TopDestination.SETTINGS -> stringResource(R.string.nav_settings)
                            },
                            style = MaterialTheme.typography.headlineSmall
                        )
                    },
                    actions = {
                        if (activeTab == TopDestination.DOWNLOADS) {
                            IconButton(
                                onClick = { showSearch = !showSearch },
                                modifier = Modifier.testTag("toggle_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = "Search downloads"
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            },
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            floatingActionButton = {
                if (activeTab != TopDestination.SETTINGS) {
                    FloatingActionButton(
                        onClick = { viewModel.openAddSheet() },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("add_download_fab")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = stringResource(R.string.action_add_download)
                        )
                    }
                }
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar {
                        TopDestination.entries.forEach { dest ->
                            val selected = activeTab == dest
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest) },
                                icon = {
                                    val badgeCount = if (dest == TopDestination.DOWNLOADS) state.activeCount else 0
                                    if (badgeCount > 0) {
                                        BadgedBox(badge = { Badge { Text("$badgeCount") } }) {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = stringResource(dest.labelRes)
                                            )
                                        }
                                    } else {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = stringResource(dest.labelRes)
                                        )
                                    }
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                modifier = Modifier.testTag("nav_${dest.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(modifier = Modifier.fillMaxHeight()) {
                        TopDestination.entries.forEach { dest ->
                            val selected = activeTab == dest
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(dest) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                modifier = Modifier.testTag("rail_${dest.name.lowercase()}")
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = DownloadsRoute,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<DownloadsRoute> {
                        DownloadsScreen(
                            state = state,
                            showSearch = showSearch,
                            onSearchQueryChange = viewModel::setSearchQuery,
                            onToggleSearch = { showSearch = !showSearch },
                            onSelectFilter = viewModel::setFilter,
                            onPauseAll = viewModel::pauseAll,
                            onResumeAll = {
                                ensureNotificationPermissionIfNeeded()
                                viewModel.resumeAll()
                            },
                            onAddClick = { viewModel.openAddSheet() },
                            onInspect = { viewModel.openInspector(it.task.id) },
                            onPause = viewModel::pause,
                            onResume = {
                                ensureNotificationPermissionIfNeeded()
                                viewModel.resume(it)
                            },
                            onRetry = {
                                ensureNotificationPermissionIfNeeded()
                                viewModel.retry(it)
                            },
                            onOpen = ::openDownloadedFile,
                            onDelete = { id -> viewModel.delete(id, deleteFile = true) }
                        )
                    }

                    composable<VaultRoute> {
                        VaultScreen(
                            state = state,
                            onSelectCategory = viewModel::setVaultCategory,
                            onOpen = ::openDownloadedFile,
                            onShare = ::shareDownloadedFile,
                            onInspect = { viewModel.openInspector(it.task.id) },
                            onDelete = { id -> viewModel.delete(id, deleteFile = false) },
                            onClearCompleted = viewModel::clearCompletedHistory
                        )
                    }

                    composable<SettingsRoute> {
                        SettingsScreen(
                            settings = state.settings,
                            appStorageBytes = appStorageBytes,
                            hasNotificationPermission = hasNotificationPermission,
                            onRequestNotificationPermission = ::ensureNotificationPermissionIfNeeded,
                            onDefaultThreadsChange = viewModel::setDefaultThreads,
                            onMaxConcurrentChange = viewModel::setMaxConcurrent,
                            onSpeedLimitChange = viewModel::setSpeedLimitKbps,
                            onWifiOnlyChange = viewModel::setWifiOnly,
                            onAutoRetryChange = viewModel::setAutoRetry,
                            onThemeModeChange = viewModel::setThemeMode
                        )
                    }
                }
            }
        }
    }

    if (showAddSheet) {
        AddDownloadSheet(
            initialUrl = prefilledUrl,
            defaultThreads = state.settings.defaultThreads,
            defaultWifiOnly = state.settings.wifiOnly,
            probeState = probeState,
            onProbeUrl = viewModel::probeUrl,
            onResetProbe = viewModel::resetProbe,
            onEnqueueSingle = { url, name, threads, wifiOnly, startNow, preProbed ->
                if (startNow) ensureNotificationPermissionIfNeeded()
                viewModel.enqueueSingle(url, name, threads, wifiOnly, startNow, preProbed)
            },
            onEnqueueBatch = { batchText, threads, wifiOnly, startNow ->
                if (startNow) ensureNotificationPermissionIfNeeded()
                viewModel.enqueueBatch(batchText, threads, wifiOnly, startNow)
            },
            onDismiss = viewModel::dismissAddSheet
        )
    }

    inspectorTask?.let { selectedItem ->
        DownloadInspectorSheet(
            item = selectedItem,
            liveStats = state.liveStats[selectedItem.task.id],
            onPause = { viewModel.pause(selectedItem.task.id) },
            onResume = {
                ensureNotificationPermissionIfNeeded()
                viewModel.resume(selectedItem.task.id)
            },
            onRetry = {
                ensureNotificationPermissionIfNeeded()
                viewModel.retry(selectedItem.task.id)
            },
            onOpen = { openDownloadedFile(selectedItem) },
            onShare = { shareDownloadedFile(selectedItem) },
            onDelete = { deleteFile -> viewModel.delete(selectedItem.task.id, deleteFile) },
            onCopiedMessage = {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("URL copied to clipboard")
                }
            },
            onDismiss = viewModel::dismissInspector
        )
    }
}
