package com.example.engine

import kotlinx.coroutines.delay
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Shared thread-safe token bucket limiter across all concurrent download segments.
 */
class SpeedLimiter {
    private val maxBytesPerSecond = AtomicLong(0L) // 0 = unlimited
    private val windowStartMs = AtomicLong(System.currentTimeMillis())
    private val bytesInCurrentWindow = AtomicLong(0L)
    private val activeDownloads = AtomicInteger(0)

    fun setLimitKbps(kbps: Int) {
        maxBytesPerSecond.set(if (kbps <= 0) 0L else kbps.toLong() * 1024L)
    }

    fun setActiveCount(count: Int) {
        activeDownloads.set(count.coerceAtLeast(1))
    }

    suspend fun acquire(bytesRead: Int) {
        val limit = maxBytesPerSecond.get()
        if (limit <= 0L || bytesRead <= 0) return

        val now = System.currentTimeMillis()
        val start = windowStartMs.get()
        val elapsed = now - start

        if (elapsed >= 1000L) {
            if (windowStartMs.compareAndSet(start, now)) {
                bytesInCurrentWindow.set(0L)
            }
        }

        val currentBytes = bytesInCurrentWindow.addAndGet(bytesRead.toLong())
        if (currentBytes > limit) {
            val remainingMs = 1000L - (System.currentTimeMillis() - windowStartMs.get())
            if (remainingMs in 1L..1000L) {
                delay(remainingMs)
            }
            windowStartMs.set(System.currentTimeMillis())
            bytesInCurrentWindow.set(0L)
        }
    }
}
