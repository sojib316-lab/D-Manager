package com.example.engine

import com.example.data.model.FileCategory
import com.example.data.model.LinkProbeResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

class HttpLinkProber(private val okHttpClient: OkHttpClient) {

    suspend fun probe(rawUrl: String): LinkProbeResult = withContext(Dispatchers.IO) {
        val url = rawUrl.trim()
        if (!Formatters.isValidHttpUrl(url)) {
            return@withContext LinkProbeResult(
                originalUrl = url,
                resolvedUrl = url,
                fileName = "invalid_url",
                totalBytes = -1L,
                supportsRanges = false,
                mimeType = "application/octet-stream",
                category = FileCategory.OTHER,
                isReachable = false,
                errorMessage = "Enter a valid http:// or https:// URL"
            )
        }

        // 1. Try HEAD request first
        val headAttempt = runCatching {
            val req = Request.Builder()
                .url(url)
                .head()
                .header("User-Agent", USER_AGENT)
                .build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val resolved = resp.request.url.toString()
                    val mime = resp.header("Content-Type")?.substringBefore(';')?.trim()
                        ?: "application/octet-stream"
                    val contentLength = resp.header("Content-Length")?.toLongOrNull() ?: -1L
                    val acceptRanges = resp.header("Accept-Ranges")?.lowercase()
                    val supportsRanges = acceptRanges == "bytes" && contentLength > 0L
                    val fileName = Formatters.inferFileName(
                        resp.header("Content-Disposition"),
                        resolved,
                        mime
                    )
                    LinkProbeResult(
                        originalUrl = url,
                        resolvedUrl = resolved,
                        fileName = fileName,
                        totalBytes = contentLength,
                        supportsRanges = supportsRanges,
                        mimeType = mime,
                        category = FileCategory.infer(fileName, mime),
                        eTag = resp.header("ETag"),
                        lastModified = resp.header("Last-Modified"),
                        isReachable = true
                    )
                } else {
                    null
                }
            }
        }.getOrNull()

        if (headAttempt != null && headAttempt.totalBytes > 0L && headAttempt.supportsRanges) {
            return@withContext headAttempt
        }

        // 2. Fallback to GET Range: bytes=0-0 (handles servers blocking HEAD or omitting Accept-Ranges on HEAD)
        val rangeAttempt = runCatching {
            val req = Request.Builder()
                .url(headAttempt?.resolvedUrl ?: url)
                .get()
                .header("Range", "bytes=0-0")
                .header("User-Agent", USER_AGENT)
                .build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful && resp.code != 206) {
                    return@use LinkProbeResult(
                        originalUrl = url,
                        resolvedUrl = resp.request.url.toString(),
                        fileName = Formatters.inferFileName(null, url, null),
                        totalBytes = -1L,
                        supportsRanges = false,
                        mimeType = "application/octet-stream",
                        category = FileCategory.OTHER,
                        isReachable = false,
                        errorMessage = "HTTP ${resp.code}: ${resp.message.ifBlank { "Server error" }}"
                    )
                }

                val resolved = resp.request.url.toString()
                val mime = resp.header("Content-Type")?.substringBefore(';')?.trim()
                    ?: headAttempt?.mimeType
                    ?: "application/octet-stream"
                val contentRangeTotal = Formatters.parseContentRangeTotal(resp.header("Content-Range"))
                val contentLength = if (resp.code == 206 && contentRangeTotal > 0L) {
                    contentRangeTotal
                } else {
                    resp.header("Content-Length")?.toLongOrNull() ?: headAttempt?.totalBytes ?: -1L
                }
                val supportsRanges = resp.code == 206 ||
                    resp.header("Accept-Ranges")?.equals("bytes", ignoreCase = true) == true
                val fileName = Formatters.inferFileName(
                    resp.header("Content-Disposition"),
                    resolved,
                    mime
                )

                LinkProbeResult(
                    originalUrl = url,
                    resolvedUrl = resolved,
                    fileName = fileName,
                    totalBytes = contentLength,
                    supportsRanges = supportsRanges && contentLength > 0L,
                    mimeType = mime,
                    category = FileCategory.infer(fileName, mime),
                    eTag = resp.header("ETag") ?: headAttempt?.eTag,
                    lastModified = resp.header("Last-Modified") ?: headAttempt?.lastModified,
                    isReachable = true
                )
            }
        }

        return@withContext rangeAttempt.getOrElse { error ->
            headAttempt ?: LinkProbeResult(
                originalUrl = url,
                resolvedUrl = url,
                fileName = Formatters.inferFileName(null, url, null),
                totalBytes = -1L,
                supportsRanges = false,
                mimeType = "application/octet-stream",
                category = FileCategory.OTHER,
                isReachable = false,
                errorMessage = error.localizedMessage ?: "Network probe failed"
            )
        }
    }

    companion object {
        const val USER_AGENT = "ProDownloadManager/1.0 (Android)"
    }
}
