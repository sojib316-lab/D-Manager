package com.example.engine

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import com.example.data.local.SegmentEntity
import com.example.data.model.DownloadStatus
import com.example.data.model.FileCategory
import com.example.data.model.LinkProbeResult
import com.example.data.preferences.DownloaderSettings
import com.example.data.preferences.SettingsDataStore
import com.example.service.DownloadForegroundService
import com.example.service.NotificationHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

data class LiveTransferStats(
    val downloadId: Long,
    val fileName: String,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val speedBytesPerSec: Long,
    val etaSeconds: Long,
    val activeThreads: Int
)

class DownloadEngine(
    private val context: Context,
    private val dao: DownloadDao,
    private val settingsDataStore: SettingsDataStore,
    private val okHttpClient: OkHttpClient,
    private val linkProber: HttpLinkProber,
    private val storageExporter: StorageExporter,
    private val notificationHelper: NotificationHelper
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val runningJobs = ConcurrentHashMap<Long, Job>()
    private val pausedByUserIds = ConcurrentHashMap.newKeySet<Long>()
    private val deletedIds = ConcurrentHashMap.newKeySet<Long>()
    private val speedLimiter = SpeedLimiter()

    @Volatile
    private var currentSettings = DownloaderSettings()

    private val _liveStats = MutableStateFlow<Map<Long, LiveTransferStats>>(emptyMap())
    val liveStats: StateFlow<Map<Long, LiveTransferStats>> = _liveStats.asStateFlow()

    private val _aggregateSpeedBps = MutableStateFlow(0L)
    val aggregateSpeedBps: StateFlow<Long> = _aggregateSpeedBps.asStateFlow()

    private val _speedHistory = MutableStateFlow<List<Float>>(List(24) { 0f })
    val speedHistory: StateFlow<List<Float>> = _speedHistory.asStateFlow()

    init {
        scope.launch {
            settingsDataStore.settingsFlow.collect { settings ->
                currentSettings = settings
                speedLimiter.setLimitKbps(settings.speedLimitKbps)
                scheduleNextQueued()
            }
        }

        scope.launch {
            // Reset any tasks left running from a killed process to PAUSED cleanly
            val stale = dao.getPendingOrActiveTasks()
                .filter { it.downloadStatus.isRunning }
            for (item in stale) {
                dao.updateStatus(item.id, DownloadStatus.PAUSED.name, null)
            }
            scheduleNextQueued()
        }

        // Sample aggregate speed every 750ms for live telemetry sparkline
        scope.launch {
            while (isActive) {
                val statsMap = _liveStats.value
                val totalSpeed = statsMap.values.sumOf { it.speedBytesPerSec }
                _aggregateSpeedBps.value = totalSpeed
                speedLimiter.setActiveCount(statsMap.size.coerceAtLeast(1))
                val mbps = totalSpeed / (1024f * 1024f)
                _speedHistory.update { prev ->
                    (prev.drop(1) + mbps).takeLast(24)
                }
                delay(750L)
            }
        }
    }

    suspend fun enqueueDownload(
        rawUrl: String,
        customFileName: String? = null,
        requestedThreads: Int? = null,
        wifiOnly: Boolean? = null,
        startImmediately: Boolean = true,
        preProbed: LinkProbeResult? = null
    ): Long {
        val settings = settingsDataStore.settingsFlow.first()
        val probe = preProbed ?: linkProber.probe(rawUrl)

        val finalName = Formatters.sanitizeFileName(
            customFileName?.takeIf { it.isNotBlank() } ?: probe.fileName
        )
        val threads = (requestedThreads ?: settings.defaultThreads).coerceIn(1, 8)
        val effectiveThreads = if (probe.supportsRanges && probe.totalBytes > 256 * 1024L) threads else 1
        val entity = DownloadEntity(
            url = rawUrl.trim(),
            resolvedUrl = probe.resolvedUrl.ifBlank { rawUrl.trim() },
            fileName = finalName,
            mimeType = probe.mimeType,
            category = FileCategory.infer(finalName, probe.mimeType).name,
            totalBytes = probe.totalBytes,
            downloadedBytes = 0L,
            status = if (startImmediately) DownloadStatus.QUEUED.name else DownloadStatus.PAUSED.name,
            threadCount = effectiveThreads,
            supportsRanges = probe.supportsRanges,
            wifiOnly = wifiOnly ?: settings.wifiOnly,
            eTag = probe.eTag,
            lastModified = probe.lastModified,
            errorMessage = if (!probe.isReachable) probe.errorMessage else null
        )

        val downloadId = dao.insertTask(entity)
        val partFile = storageExporter.createPartFile(downloadId, finalName)
        dao.updateTask(entity.copy(id = downloadId, partFilePath = partFile.absolutePath))

        val ranges = Formatters.computeSegmentRanges(probe.totalBytes, effectiveThreads)
        val segments = ranges.mapIndexed { idx, (start, end) ->
            SegmentEntity(
                downloadId = downloadId,
                segmentIndex = idx,
                startByte = start,
                endByte = end,
                downloadedBytes = 0L,
                isCompleted = false
            )
        }
        dao.insertSegments(segments)

        if (startImmediately) {
            scheduleNextQueued()
        }
        return downloadId
    }

    suspend fun pause(downloadId: Long) {
        pausedByUserIds.add(downloadId)
        runningJobs.remove(downloadId)?.cancel()
        removeLiveStat(downloadId)
        dao.updateStatus(downloadId, DownloadStatus.PAUSED.name, null)
        scheduleNextQueued()
    }

    suspend fun resume(downloadId: Long) {
        pausedByUserIds.remove(downloadId)
        deletedIds.remove(downloadId)
        val task = dao.getTaskById(downloadId) ?: return
        if (task.downloadStatus == DownloadStatus.COMPLETED) return
        dao.updateStatus(downloadId, DownloadStatus.QUEUED.name, null)
        scheduleNextQueued()
    }

    suspend fun retry(downloadId: Long) {
        pausedByUserIds.remove(downloadId)
        deletedIds.remove(downloadId)
        val task = dao.getTaskById(downloadId) ?: return
        dao.updateTask(
            task.copy(
                status = DownloadStatus.QUEUED.name,
                errorMessage = null,
                retryCount = 0,
                updatedAt = System.currentTimeMillis()
            )
        )
        scheduleNextQueued()
    }

    suspend fun pauseAll() {
        val activeAndQueued = dao.getPendingOrActiveTasks()
        for (task in activeAndQueued) {
            if (task.downloadStatus.isActiveOrPending) {
                pausedByUserIds.add(task.id)
                runningJobs.remove(task.id)?.cancel()
                removeLiveStat(task.id)
                dao.updateStatus(task.id, DownloadStatus.PAUSED.name, null)
            }
        }
    }

    suspend fun resumeAll() {
        val pending = dao.getPendingOrActiveTasks()
        for (task in pending) {
            if (task.downloadStatus == DownloadStatus.PAUSED || task.downloadStatus == DownloadStatus.FAILED) {
                pausedByUserIds.remove(task.id)
                dao.updateStatus(task.id, DownloadStatus.QUEUED.name, null)
            }
        }
        scheduleNextQueued()
    }

    suspend fun delete(downloadId: Long, deleteLocalFile: Boolean) {
        deletedIds.add(downloadId)
        pausedByUserIds.add(downloadId)
        runningJobs.remove(downloadId)?.cancel()
        removeLiveStat(downloadId)
        val task = dao.getTaskById(downloadId)
        if (task != null) {
            if (deleteLocalFile || task.downloadStatus != DownloadStatus.COMPLETED) {
                storageExporter.deleteLocalFiles(task.partFilePath, task.exportedUri)
            }
            dao.deleteTaskById(downloadId)
        }
        scheduleNextQueued()
    }

    private fun scheduleNextQueued() {
        scope.launch {
            val maxConcurrent = currentSettings.maxConcurrentDownloads.coerceIn(1, 5)
            val currentRunning = runningJobs.size
            if (currentRunning >= maxConcurrent) return@launch

            val queued = dao.getQueuedTasks()
            var slotsAvailable = maxConcurrent - currentRunning
            for (task in queued) {
                if (slotsAvailable <= 0) break
                if (!runningJobs.containsKey(task.id)) {
                    startDownloadJob(task.id)
                    slotsAvailable--
                }
            }
        }
    }

    private fun startDownloadJob(downloadId: Long) {
        if (runningJobs.containsKey(downloadId)) return
        val job = scope.launch {
            try {
                executeDownload(downloadId)
            } finally {
                runningJobs.remove(downloadId)
                removeLiveStat(downloadId)
                scheduleNextQueued()
            }
        }
        runningJobs[downloadId] = job
    }

    private suspend fun executeDownload(downloadId: Long) {
        var task = dao.getTaskById(downloadId) ?: return
        pausedByUserIds.remove(downloadId)
        if (deletedIds.contains(downloadId)) return

        if (task.wifiOnly && !isOnWifiOrUnmetered()) {
            dao.updateStatus(downloadId, DownloadStatus.PAUSED.name, "Waiting for Wi-Fi connection")
            return
        }

        DownloadForegroundService.start(context)
        dao.updateStatus(downloadId, DownloadStatus.CONNECTING.name, null)

        // Re-probe if totalBytes unknown or no segments yet
        var segments = dao.getSegmentsForDownload(downloadId)
        if (segments.isEmpty() || task.resolvedUrl.isBlank()) {
            val probe = linkProber.probe(task.url)
            if (!probe.isReachable) {
                handleFailure(task, probe.errorMessage ?: "Unable to connect to server")
                return
            }
            val effectiveThreads = if (probe.supportsRanges && probe.totalBytes > 256 * 1024L) {
                task.threadCount.coerceIn(1, 8)
            } else {
                1
            }
            val partFile = if (task.partFilePath.isNotBlank()) {
                File(task.partFilePath)
            } else {
                storageExporter.createPartFile(downloadId, probe.fileName)
            }
            task = task.copy(
                resolvedUrl = probe.resolvedUrl,
                mimeType = probe.mimeType,
                totalBytes = probe.totalBytes,
                supportsRanges = probe.supportsRanges,
                threadCount = effectiveThreads,
                partFilePath = partFile.absolutePath,
                eTag = probe.eTag,
                lastModified = probe.lastModified
            )
            dao.updateTask(task)

            val ranges = Formatters.computeSegmentRanges(probe.totalBytes, effectiveThreads)
            val createdSegments = ranges.mapIndexed { idx, (start, end) ->
                SegmentEntity(
                    downloadId = downloadId,
                    segmentIndex = idx,
                    startByte = start,
                    endByte = end,
                    downloadedBytes = 0L,
                    isCompleted = false
                )
            }
            dao.deleteSegmentsForDownload(downloadId)
            dao.insertSegments(createdSegments)
            segments = dao.getSegmentsForDownload(downloadId)
        }

        val partFile = File(task.partFilePath.ifBlank {
            storageExporter.createPartFile(downloadId, task.fileName).absolutePath
        })
        partFile.parentFile?.mkdirs()

        // Ensure part file is pre-sized for multi-segment random writes
        if (task.totalBytes > 0L && partFile.length() != task.totalBytes) {
            RandomAccessFile(partFile, "rw").use { raf ->
                if (raf.length() < task.totalBytes) {
                    raf.setLength(task.totalBytes)
                }
            }
        }

        dao.updateStatus(downloadId, DownloadStatus.DOWNLOADING.name, null)

        val totalDownloadedAtomic = AtomicLong(segments.sumOf { it.downloadedBytes })
        val segmentDownloadedMap = ConcurrentHashMap<Long, AtomicLong>().apply {
            segments.forEach { put(it.id, AtomicLong(it.downloadedBytes)) }
        }
        val segmentDoneMap = ConcurrentHashMap<Long, Boolean>().apply {
            segments.forEach { put(it.id, it.isCompleted) }
        }

        val speedWindowStartBytes = AtomicLong(totalDownloadedAtomic.get())
        val speedWindowStartTime = AtomicLong(System.currentTimeMillis())

            try {
                coroutineScope {
                    val tickerJob = launch {
                        while (isActive) {
                            delay(300L)
                            val now = System.currentTimeMillis()
                            val currentTotal = totalDownloadedAtomic.get()
                            val elapsedMs = (now - speedWindowStartTime.get()).coerceAtLeast(1L)
                            val deltaBytes = (currentTotal - speedWindowStartBytes.get()).coerceAtLeast(0L)
                            val speedBps = (deltaBytes * 1000L) / elapsedMs
                            if (elapsedMs >= 1500L) {
                                speedWindowStartBytes.set(currentTotal)
                                speedWindowStartTime.set(now)
                            }

                            val eta = if (task.totalBytes > 0L && speedBps > 0L) {
                                ((task.totalBytes - currentTotal).coerceAtLeast(0L)) / speedBps
                            } else {
                                -1L
                            }

                            val activeThreads = segmentDoneMap.values.count { !it }.coerceAtLeast(1)
                            _liveStats.update { current ->
                                current + (downloadId to LiveTransferStats(
                                    downloadId = downloadId,
                                    fileName = task.fileName,
                                    downloadedBytes = currentTotal,
                                    totalBytes = task.totalBytes,
                                    speedBytesPerSec = speedBps,
                                    etaSeconds = eta,
                                    activeThreads = activeThreads
                                ))
                            }

                            dao.updateProgress(downloadId, currentTotal, task.totalBytes)
                            for (seg in segments) {
                                val bytes = segmentDownloadedMap[seg.id]?.get() ?: seg.downloadedBytes
                                val done = segmentDoneMap[seg.id] ?: seg.isCompleted
                                dao.updateSegmentProgress(seg.id, bytes, done)
                            }
                        }
                    }

                    try {
                        if (task.supportsRanges && task.totalBytes > 0L && segments.size > 1) {
                            val jobs = segments.map { segment ->
                                async(Dispatchers.IO) {
                                    downloadSegment(
                                        task = task,
                                        segment = segment,
                                        partFile = partFile,
                                        segmentCounter = segmentDownloadedMap[segment.id]!!,
                                        totalCounter = totalDownloadedAtomic,
                                        onDone = { segmentDoneMap[segment.id] = true }
                                    )
                                }
                            }
                            jobs.awaitAll()
                        } else {
                            val singleSeg = segments.first()
                            downloadSingleStream(
                                task = task,
                                segment = singleSeg,
                                partFile = partFile,
                                segmentCounter = segmentDownloadedMap[singleSeg.id]!!,
                                totalCounter = totalDownloadedAtomic,
                                onDone = { segmentDoneMap[singleSeg.id] = true }
                            )
                        }
                    } finally {
                        tickerJob.cancel()
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                val latestTotal = totalDownloadedAtomic.get()
                dao.updateProgress(downloadId, latestTotal, task.totalBytes)
                for (seg in segments) {
                    val bytes = segmentDownloadedMap[seg.id]?.get() ?: seg.downloadedBytes
                    val done = segmentDoneMap[seg.id] ?: seg.isCompleted
                    dao.updateSegmentProgress(seg.id, bytes, done)
                }
                handleFailure(task, e.localizedMessage ?: "Network transfer error")
                return
            }

        // Flush final segment progress before finalizing
        val finalBytes = totalDownloadedAtomic.get()
        for (seg in segments) {
            val bytes = segmentDownloadedMap[seg.id]?.get() ?: seg.downloadedBytes
            val done = segmentDoneMap[seg.id] ?: seg.isCompleted
            dao.updateSegmentProgress(seg.id, bytes, done)
        }

        if (pausedByUserIds.contains(downloadId) || deletedIds.contains(downloadId)) {
            return
        }

        val finalTotal = if (task.totalBytes > 0L) task.totalBytes else finalBytes
        val (exportedUri, finalLocalPath) = storageExporter.exportCompletedFile(
            partFile = partFile,
            fileName = task.fileName,
            mimeType = task.mimeType
        )
        dao.markCompleted(
            id = downloadId,
            downloadedBytes = finalBytes,
            totalBytes = finalTotal,
            exportedUri = exportedUri,
            finalPath = finalLocalPath
        )
        notificationHelper.notifyCompleted(downloadId, task.fileName, finalTotal)
    }

    private suspend fun downloadSegment(
        task: DownloadEntity,
        segment: SegmentEntity,
        partFile: File,
        segmentCounter: AtomicLong,
        totalCounter: AtomicLong,
        onDone: () -> Unit
    ) {
        if (segment.isCompleted) {
            onDone()
            return
        }

        val alreadyDownloaded = segmentCounter.get()
        val currentStart = segment.startByte + alreadyDownloaded
        if (currentStart > segment.endByte) {
            onDone()
            return
        }

        val reqBuilder = Request.Builder()
            .url(task.resolvedUrl)
            .header("User-Agent", HttpLinkProber.USER_AGENT)
            .header("Range", "bytes=$currentStart-${segment.endByte}")
        if (!task.eTag.isNullOrBlank()) {
            reqBuilder.header("If-Range", task.eTag)
        }

        val call = okHttpClient.newCall(reqBuilder.build())
        call.execute().use { response ->
            if (!response.isSuccessful && response.code != 206) {
                error("HTTP ${response.code}: ${response.message}")
            }
            val body = response.body ?: error("Empty response body")
            val buffer = ByteArray(DEFAULT_BUFFER_BYTES)

            RandomAccessFile(partFile, "rw").use { raf ->
                val channel = raf.channel
                var writePos = currentStart
                body.byteStream().use { input ->
                    while (true) {
                        if (pausedByUserIds.contains(task.id) || deletedIds.contains(task.id)) {
                            throw CancellationException("Paused or canceled by user")
                        }
                        val read = input.read(buffer)
                        if (read == -1) break

                        speedLimiter.acquire(read)

                        val byteBuffer = ByteBuffer.wrap(buffer, 0, read)
                        while (byteBuffer.hasRemaining()) {
                            writePos += channel.write(byteBuffer, writePos)
                        }
                        segmentCounter.addAndGet(read.toLong())
                        totalCounter.addAndGet(read.toLong())
                    }
                }
            }
            onDone()
        }
    }

    private suspend fun downloadSingleStream(
        task: DownloadEntity,
        segment: SegmentEntity,
        partFile: File,
        segmentCounter: AtomicLong,
        totalCounter: AtomicLong,
        onDone: () -> Unit
    ) {
        val alreadyDownloaded = segmentCounter.get()
        val reqBuilder = Request.Builder()
            .url(task.resolvedUrl)
            .header("User-Agent", HttpLinkProber.USER_AGENT)

        val attemptResume = task.supportsRanges && alreadyDownloaded > 0L
        if (attemptResume) {
            reqBuilder.header("Range", "bytes=$alreadyDownloaded-")
        }

        okHttpClient.newCall(reqBuilder.build()).execute().use { response ->
            if (!response.isSuccessful && response.code != 206) {
                error("HTTP ${response.code}: ${response.message}")
            }
            val body = response.body ?: error("Empty response body")
            val isResumed206 = response.code == 206

            if (!isResumed206 && alreadyDownloaded > 0L) {
                // Server ignored Range and sent full stream from byte 0
                segmentCounter.set(0L)
                totalCounter.set(0L)
            }

            var writePos = if (isResumed206) alreadyDownloaded else 0L
            val buffer = ByteArray(DEFAULT_BUFFER_BYTES)

            RandomAccessFile(partFile, "rw").use { raf ->
                if (!isResumed206 && task.totalBytes <= 0L) {
                    raf.setLength(0L)
                }
                val channel = raf.channel
                body.byteStream().use { input ->
                    while (true) {
                        if (pausedByUserIds.contains(task.id) || deletedIds.contains(task.id)) {
                            throw CancellationException("Paused or canceled by user")
                        }
                        val read = input.read(buffer)
                        if (read == -1) break

                        speedLimiter.acquire(read)

                        val byteBuffer = ByteBuffer.wrap(buffer, 0, read)
                        while (byteBuffer.hasRemaining()) {
                            writePos += channel.write(byteBuffer, writePos)
                        }
                        segmentCounter.addAndGet(read.toLong())
                        totalCounter.addAndGet(read.toLong())
                    }
                }
            }
            onDone()
        }
    }

    private suspend fun handleFailure(task: DownloadEntity, errorMsg: String) {
        if (pausedByUserIds.contains(task.id) || deletedIds.contains(task.id)) return
        if (currentSettings.autoRetry && task.retryCount < MAX_AUTO_RETRIES) {
            val nextRetry = task.retryCount + 1
            dao.updateTask(
                task.copy(
                    status = DownloadStatus.QUEUED.name,
                    retryCount = nextRetry,
                    errorMessage = "Retrying ($nextRetry/$MAX_AUTO_RETRIES): $errorMsg",
                    updatedAt = System.currentTimeMillis()
                )
            )
            delay(1500L * nextRetry)
        } else {
            dao.updateStatus(task.id, DownloadStatus.FAILED.name, errorMsg)
            notificationHelper.notifyFailed(task.id, task.fileName, errorMsg)
        }
    }

    private fun removeLiveStat(downloadId: Long) {
        _liveStats.update { it - downloadId }
    }

    private fun isOnWifiOrUnmetered(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return true
        val activeNetwork = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ||
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    companion object {
        private const val DEFAULT_BUFFER_BYTES = 32 * 1024
        private const val MAX_AUTO_RETRIES = 3
    }
}
