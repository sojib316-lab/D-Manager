package com.example.engine

import android.webkit.MimeTypeMap
import java.net.URLDecoder
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

object Formatters {

    private val URL_REGEX = Regex(
        """https?://[^\s<>"'{}|\\^`\[\]]+""",
        RegexOption.IGNORE_CASE
    )

    fun formatBytes(bytes: Long): String {
        if (bytes < 0L) return "Unknown"
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.US, "%.2f MB", mb)
        val gb = mb / 1024.0
        return String.format(Locale.US, "%.2f GB", gb)
    }

    fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0L) return "0 KB/s"
        val kb = bytesPerSec / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.1f KB/s", kb)
        val mb = kb / 1024.0
        return String.format(Locale.US, "%.2f MB/s", mb)
    }

    fun formatEta(seconds: Long): String {
        if (seconds < 0L) return "--:--"
        val hrs = seconds / 3600L
        val mins = (seconds % 3600L) / 60L
        val secs = seconds % 60L
        return if (hrs > 0L) {
            String.format(Locale.US, "%dh %02dm", hrs, mins)
        } else if (mins > 0L) {
            String.format(Locale.US, "%dm %02ds", mins, secs)
        } else {
            String.format(Locale.US, "%ds", secs)
        }
    }

    fun extractUrlsFromText(input: String): List<String> {
        return URL_REGEX.findAll(input)
            .map { it.value.trimEnd('.', ',', ';', ')') }
            .distinct()
            .toList()
    }

    fun isValidHttpUrl(url: String): Boolean {
        val trimmed = url.trim()
        return (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)) &&
            trimmed.length > 10
    }

    fun sanitizeFileName(rawName: String): String {
        val cleaned = rawName
            .replace(Regex("""[\\/:*?"<>|\u0000-\u001F]"""), "_")
            .trim()
            .trim('.')
        return if (cleaned.isEmpty()) "download_${System.currentTimeMillis()}" else cleaned
    }

    fun parseContentDispositionFileName(header: String?): String? {
        if (header.isNullOrBlank()) return null

        // RFC 5987 filename*=UTF-8''...
        val extRegex = Regex("""filename\*\s*=\s*(?:UTF-8|utf-8)?''([^;]+)""")
        extRegex.find(header)?.groupValues?.getOrNull(1)?.let { encoded ->
            val decoded = runCatching { URLDecoder.decode(encoded.trim().trim('"'), "UTF-8") }.getOrNull()
            if (!decoded.isNullOrBlank()) return sanitizeFileName(decoded)
        }

        // Standard filename="..." or filename=...
        val stdRegex = Regex("""filename\s*=\s*"?([^";]+)"?""", RegexOption.IGNORE_CASE)
        stdRegex.find(header)?.groupValues?.getOrNull(1)?.let { raw ->
            val decoded = runCatching { URLDecoder.decode(raw.trim(), "UTF-8") }.getOrElse { raw.trim() }
            if (decoded.isNotBlank()) return sanitizeFileName(decoded)
        }
        return null
    }

    fun inferFileName(contentDisposition: String?, url: String, mimeType: String?): String {
        parseContentDispositionFileName(contentDisposition)?.let { return it }

        val pathPart = url.substringBefore('?').substringBefore('#')
        val lastSegment = pathPart.substringAfterLast('/', "")
        val decodedSegment = runCatching { URLDecoder.decode(lastSegment, "UTF-8") }.getOrElse { lastSegment }
        if (decodedSegment.isNotBlank() && decodedSegment != "/" && !decodedSegment.contains("://")) {
            val sanitized = sanitizeFileName(decodedSegment)
            if (sanitized.contains('.')) return sanitized
            val ext = extensionFromMime(mimeType)
            return if (ext != null) "$sanitized.$ext" else sanitized
        }

        val ext = extensionFromMime(mimeType) ?: "bin"
        return "download_${System.currentTimeMillis()}.$ext"
    }

    fun extensionFromMime(mimeType: String?): String? {
        if (mimeType.isNullOrBlank()) return null
        val cleanMime = mimeType.substringBefore(';').trim().lowercase()
        return MimeTypeMap.getSingleton().getExtensionFromMimeType(cleanMime)
            ?: when (cleanMime) {
                "application/octet-stream" -> "bin"
                "application/zip" -> "zip"
                "application/pdf" -> "pdf"
                "application/vnd.android.package-archive" -> "apk"
                "text/plain" -> "txt"
                else -> null
            }
    }

    fun parseContentRangeTotal(contentRange: String?): Long {
        if (contentRange.isNullOrBlank()) return -1L
        // Example: "bytes 0-0/1234567" or "bytes 0-1023/*"
        val totalStr = contentRange.substringAfter('/', "").trim()
        return totalStr.toLongOrNull() ?: -1L
    }

    fun computeSegmentRanges(totalBytes: Long, requestedThreads: Int): List<Pair<Long, Long>> {
        if (totalBytes <= 0L) return listOf(0L to -1L)
        val threads = max(1, min(requestedThreads, 8))
        if (threads == 1 || totalBytes < 256 * 1024L) {
            return listOf(0L to (totalBytes - 1L))
        }
        val chunkSize = totalBytes / threads
        val ranges = mutableListOf<Pair<Long, Long>>()
        var start = 0L
        for (i in 0 until threads) {
            val end = if (i == threads - 1) totalBytes - 1L else (start + chunkSize - 1L)
            ranges.add(start to end)
            start = end + 1L
        }
        return ranges
    }
}
