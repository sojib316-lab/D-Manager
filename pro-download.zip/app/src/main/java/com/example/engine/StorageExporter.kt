package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

class StorageExporter(private val context: Context) {

    private val activeDir: File
        get() {
            val base = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            return File(base, "active").apply { if (!exists()) mkdirs() }
        }

    private val completedDir: File
        get() {
            val base = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            return File(base, "completed").apply { if (!exists()) mkdirs() }
        }

    fun createPartFile(downloadId: Long, fileName: String): File {
        val safeName = Formatters.sanitizeFileName(fileName)
        return File(activeDir, "${downloadId}_${safeName}.part")
    }

    fun uniqueCompletedFile(fileName: String): File {
        val safeName = Formatters.sanitizeFileName(fileName)
        var candidate = File(completedDir, safeName)
        if (!candidate.exists()) return candidate

        val base = safeName.substringBeforeLast('.', safeName)
        val ext = safeName.substringAfterLast('.', "")
        var index = 1
        while (candidate.exists()) {
            val numbered = if (ext.isNotEmpty() && base != safeName) {
                "${base}_($index).$ext"
            } else {
                "${safeName}_($index)"
            }
            candidate = File(completedDir, numbered)
            index++
        }
        return candidate
    }

    /**
     * Exports a finished part file into the public MediaStore Downloads collection (API 29+)
     * or moves it into the app's Downloads/completed folder exposed via FileProvider (API 26-28).
     * Returns Pair(exportedContentUriString, localFilePathOrEmpty).
     */
    suspend fun exportCompletedFile(
        partFile: File,
        fileName: String,
        mimeType: String
    ): Pair<String, String> = withContext(Dispatchers.IO) {
        val safeName = Formatters.sanitizeFileName(fileName)
        val cleanMime = mimeType.ifBlank { "application/octet-stream" }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, cleanMime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ProDownload")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val insertedUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (insertedUri != null) {
                val copied = runCatching {
                    resolver.openOutputStream(insertedUri)?.use { out ->
                        FileInputStream(partFile).use { input ->
                            input.copyTo(out, bufferSize = 64 * 1024)
                        }
                    } ?: error("Cannot open MediaStore output stream")

                    val doneValues = ContentValues().apply {
                        put(MediaStore.Downloads.IS_PENDING, 0)
                    }
                    resolver.update(insertedUri, doneValues, null, null)
                    true
                }.getOrElse {
                    runCatching { resolver.delete(insertedUri, null, null) }
                    false
                }

                if (copied) {
                    partFile.delete()
                    return@withContext insertedUri.toString() to ""
                }
            }
        }

        // Fallback for API 26-28 or if MediaStore insert fails
        val finalFile = uniqueCompletedFile(safeName)
        if (!partFile.renameTo(finalFile)) {
            partFile.copyTo(finalFile, overwrite = true)
            partFile.delete()
        }
        val providerUri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            finalFile
        )
        providerUri.toString() to finalFile.absolutePath
    }

    fun deleteLocalFiles(partFilePath: String, exportedUri: String) {
        if (partFilePath.isNotBlank()) {
            runCatching { File(partFilePath).delete() }
        }
        if (exportedUri.startsWith("content://media")) {
            runCatching {
                context.contentResolver.delete(Uri.parse(exportedUri), null, null)
            }
        }
    }

    fun buildOpenIntent(exportedUri: String, localPath: String, mimeType: String): Intent? {
        val uri = resolveShareableUri(exportedUri, localPath) ?: return null
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType.ifBlank { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun buildShareIntent(exportedUri: String, localPath: String, mimeType: String, fileName: String): Intent? {
        val uri = resolveShareableUri(exportedUri, localPath) ?: return null
        return Intent(Intent.ACTION_SEND).apply {
            type = mimeType.ifBlank { "*/*" }
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, fileName)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun resolveShareableUri(exportedUri: String, localPath: String): Uri? {
        if (exportedUri.isNotBlank()) {
            return Uri.parse(exportedUri)
        }
        if (localPath.isNotBlank()) {
            val file = File(localPath)
            if (file.exists()) {
                return FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
            }
        }
        return null
    }

    fun computeAppStorageBytes(): Long {
        val activeSize = activeDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        val completedSize = completedDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        return activeSize + completedSize
    }
}
