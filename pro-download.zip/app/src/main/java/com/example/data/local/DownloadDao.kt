package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.DownloadTaskWithSegments
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Transaction
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun observeAllWithSegments(): Flow<List<DownloadTaskWithSegments>>

    @Transaction
    @Query("SELECT * FROM downloads WHERE status = 'COMPLETED' ORDER BY completedAt DESC")
    fun observeCompleted(): Flow<List<DownloadTaskWithSegments>>

    @Query("SELECT COUNT(*) FROM downloads WHERE status IN ('CONNECTING', 'DOWNLOADING')")
    fun observeActiveCount(): Flow<Int>

    @Transaction
    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun getByIdWithSegments(id: Long): DownloadTaskWithSegments?

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun getTaskById(id: Long): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status = 'QUEUED' ORDER BY createdAt ASC")
    suspend fun getQueuedTasks(): List<DownloadEntity>

    @Query("SELECT * FROM downloads WHERE status IN ('CONNECTING', 'DOWNLOADING', 'PAUSED', 'QUEUED')")
    suspend fun getPendingOrActiveTasks(): List<DownloadEntity>

    @Query("SELECT COUNT(*) FROM downloads WHERE status IN ('CONNECTING', 'DOWNLOADING')")
    suspend fun getRunningCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: DownloadEntity): Long

    @Update
    suspend fun updateTask(task: DownloadEntity)

    @Query("UPDATE downloads SET status = :status, errorMessage = :errorMessage, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateStatus(
        id: Long,
        status: String,
        errorMessage: String? = null,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("UPDATE downloads SET downloadedBytes = :downloadedBytes, totalBytes = :totalBytes, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateProgress(
        id: Long,
        downloadedBytes: Long,
        totalBytes: Long,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("UPDATE downloads SET status = 'COMPLETED', downloadedBytes = :downloadedBytes, totalBytes = :totalBytes, exportedUri = :exportedUri, partFilePath = :finalPath, errorMessage = NULL, completedAt = :completedAt, updatedAt = :completedAt WHERE id = :id")
    suspend fun markCompleted(
        id: Long,
        downloadedBytes: Long,
        totalBytes: Long,
        exportedUri: String,
        finalPath: String,
        completedAt: Long = System.currentTimeMillis()
    )

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSegments(segments: List<SegmentEntity>)

    @Query("SELECT * FROM download_segments WHERE downloadId = :downloadId ORDER BY segmentIndex ASC")
    suspend fun getSegmentsForDownload(downloadId: Long): List<SegmentEntity>

    @Query("UPDATE download_segments SET downloadedBytes = :downloadedBytes, isCompleted = :isCompleted WHERE id = :segmentId")
    suspend fun updateSegmentProgress(segmentId: Long, downloadedBytes: Long, isCompleted: Boolean)

    @Query("DELETE FROM download_segments WHERE downloadId = :downloadId")
    suspend fun deleteSegmentsForDownload(downloadId: Long)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteTaskById(id: Long)

    @Query("DELETE FROM downloads WHERE status = 'COMPLETED'")
    suspend fun clearCompletedTasks()
}
