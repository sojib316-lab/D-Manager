package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.DownloadStatus
import com.example.data.model.FileCategory

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val url: String,
    val resolvedUrl: String,
    val fileName: String,
    val mimeType: String,
    val category: String = FileCategory.OTHER.name,
    val totalBytes: Long = -1L,
    val downloadedBytes: Long = 0L,
    val status: String = DownloadStatus.QUEUED.name,
    val threadCount: Int = 4,
    val supportsRanges: Boolean = false,
    val wifiOnly: Boolean = false,
    val partFilePath: String = "",
    val exportedUri: String = "",
    val eTag: String? = null,
    val lastModified: String? = null,
    val errorMessage: String? = null,
    val retryCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
) {
    val downloadStatus: DownloadStatus
        get() = runCatching { DownloadStatus.valueOf(status) }.getOrDefault(DownloadStatus.QUEUED)

    val fileCategory: FileCategory
        get() = runCatching { FileCategory.valueOf(category) }.getOrDefault(FileCategory.OTHER)
}
