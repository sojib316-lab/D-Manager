package com.example.data.repository

import android.content.Intent
import com.example.data.local.DownloadDao
import com.example.data.model.DownloadTaskWithSegments
import com.example.data.model.LinkProbeResult
import com.example.data.model.ThemeMode
import com.example.data.preferences.DownloaderSettings
import com.example.data.preferences.SettingsDataStore
import com.example.engine.DownloadEngine
import com.example.engine.HttpLinkProber
import com.example.engine.LiveTransferStats
import com.example.engine.StorageExporter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

class DownloadRepository(
    private val dao: DownloadDao,
    private val linkProber: HttpLinkProber,
    private val downloadEngine: DownloadEngine,
    private val settingsDataStore: SettingsDataStore,
    private val storageExporter: StorageExporter
) {
    val allDownloads: Flow<List<DownloadTaskWithSegments>> = dao.observeAllWithSegments()
    val completedDownloads: Flow<List<DownloadTaskWithSegments>> = dao.observeCompleted()
    val settingsFlow: Flow<DownloaderSettings> = settingsDataStore.settingsFlow

    val liveStats: StateFlow<Map<Long, LiveTransferStats>> = downloadEngine.liveStats
    val aggregateSpeedBps: StateFlow<Long> = downloadEngine.aggregateSpeedBps
    val speedHistory: StateFlow<List<Float>> = downloadEngine.speedHistory

    suspend fun probeLink(url: String): LinkProbeResult = linkProber.probe(url)

    suspend fun enqueueDownload(
        url: String,
        customFileName: String? = null,
        threads: Int? = null,
        wifiOnly: Boolean? = null,
        startImmediately: Boolean = true,
        preProbed: LinkProbeResult? = null
    ): Long {
        return downloadEngine.enqueueDownload(
            rawUrl = url,
            customFileName = customFileName,
            requestedThreads = threads,
            wifiOnly = wifiOnly,
            startImmediately = startImmediately,
            preProbed = preProbed
        )
    }

    suspend fun pause(id: Long) = downloadEngine.pause(id)
    suspend fun resume(id: Long) = downloadEngine.resume(id)
    suspend fun retry(id: Long) = downloadEngine.retry(id)
    suspend fun pauseAll() = downloadEngine.pauseAll()
    suspend fun resumeAll() = downloadEngine.resumeAll()
    suspend fun delete(id: Long, deleteFile: Boolean) = downloadEngine.delete(id, deleteFile)
    suspend fun clearCompleted() = dao.clearCompletedTasks()

    fun buildOpenIntent(exportedUri: String, localPath: String, mimeType: String): Intent? =
        storageExporter.buildOpenIntent(exportedUri, localPath, mimeType)

    fun buildShareIntent(exportedUri: String, localPath: String, mimeType: String, fileName: String): Intent? =
        storageExporter.buildShareIntent(exportedUri, localPath, mimeType, fileName)

    fun computeAppStorageBytes(): Long = storageExporter.computeAppStorageBytes()

    suspend fun setDefaultThreads(threads: Int) = settingsDataStore.setDefaultThreads(threads)
    suspend fun setMaxConcurrent(maxConcurrent: Int) = settingsDataStore.setMaxConcurrentDownloads(maxConcurrent)
    suspend fun setSpeedLimitKbps(kbps: Int) = settingsDataStore.setSpeedLimitKbps(kbps)
    suspend fun setWifiOnly(enabled: Boolean) = settingsDataStore.setWifiOnly(enabled)
    suspend fun setAutoRetry(enabled: Boolean) = settingsDataStore.setAutoRetry(enabled)
    suspend fun setThemeMode(mode: ThemeMode) = settingsDataStore.setThemeMode(mode)
}
