package com.example.data.model

data class LinkProbeResult(
    val originalUrl: String,
    val resolvedUrl: String,
    val fileName: String,
    val totalBytes: Long,
    val supportsRanges: Boolean,
    val mimeType: String,
    val category: FileCategory,
    val eTag: String? = null,
    val lastModified: String? = null,
    val isReachable: Boolean = true,
    val errorMessage: String? = null
)
