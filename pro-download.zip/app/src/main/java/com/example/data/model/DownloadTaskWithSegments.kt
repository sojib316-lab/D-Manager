package com.example.data.model

import androidx.room.Embedded
import androidx.room.Relation
import com.example.data.local.DownloadEntity
import com.example.data.local.SegmentEntity

data class DownloadTaskWithSegments(
    @Embedded
    val task: DownloadEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "downloadId"
    )
    val segments: List<SegmentEntity>
) {
    val sortedSegments: List<SegmentEntity>
        get() = segments.sortedBy { it.segmentIndex }

    val progressFraction: Float
        get() {
            if (task.downloadStatus == DownloadStatus.COMPLETED) return 1f
            if (task.totalBytes <= 0L) return 0f
            return (task.downloadedBytes.toFloat() / task.totalBytes.toFloat()).coerceIn(0f, 1f)
        }

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)
}
