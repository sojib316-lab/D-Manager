package com.example.data.model

enum class DownloadStatus {
    QUEUED,
    CONNECTING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELED;

    val isActiveOrPending: Boolean
        get() = this == QUEUED || this == CONNECTING || this == DOWNLOADING

    val isRunning: Boolean
        get() = this == CONNECTING || this == DOWNLOADING
}
