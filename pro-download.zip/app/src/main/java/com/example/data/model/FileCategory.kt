package com.example.data.model

enum class FileCategory(val label: String) {
    VIDEO("Video"),
    AUDIO("Audio"),
    ARCHIVE("Archives"),
    DOCUMENT("Docs"),
    APP("Apps"),
    IMAGE("Images"),
    OTHER("Other");

    companion object {
        fun infer(fileName: String, mimeType: String?): FileCategory {
            val ext = fileName.substringAfterLast('.', "").lowercase()
            val mime = mimeType?.lowercase().orEmpty()

            return when {
                mime.startsWith("video/") || ext in setOf("mp4", "mkv", "webm", "avi", "mov", "flv", "m4v", "ts") -> VIDEO
                mime.startsWith("audio/") || ext in setOf("mp3", "flac", "aac", "ogg", "wav", "m4a", "opus") -> AUDIO
                ext in setOf("apk", "apks", "xapk", "aab", "exe", "dmg", "deb") ||
                    mime == "application/vnd.android.package-archive" -> APP
                ext in setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso", "tgz") ||
                    mime.contains("zip") || mime.contains("compressed") || mime.contains("archive") -> ARCHIVE
                mime.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "webp", "gif", "svg", "bmp", "heic") -> IMAGE
                mime.startsWith("text/") || mime == "application/pdf" ||
                    ext in setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "csv", "json", "xml", "epub") -> DOCUMENT
                else -> OTHER
            }
        }
    }
}
