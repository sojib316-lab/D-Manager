package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pro_downloader_settings")

data class DownloaderSettings(
    val defaultThreads: Int = 4,
    val maxConcurrentDownloads: Int = 3,
    val speedLimitKbps: Int = 0,
    val wifiOnly: Boolean = false,
    val autoRetry: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.SYSTEM
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val DEFAULT_THREADS = intPreferencesKey("default_threads")
        val MAX_CONCURRENT = intPreferencesKey("max_concurrent")
        val SPEED_LIMIT_KBPS = intPreferencesKey("speed_limit_kbps")
        val WIFI_ONLY = booleanPreferencesKey("wifi_only")
        val AUTO_RETRY = booleanPreferencesKey("auto_retry")
        val THEME_MODE = stringPreferencesKey("theme_mode")
    }

    val settingsFlow: Flow<DownloaderSettings> = context.dataStore.data.map { prefs ->
        DownloaderSettings(
            defaultThreads = (prefs[Keys.DEFAULT_THREADS] ?: 4).coerceIn(1, 8),
            maxConcurrentDownloads = (prefs[Keys.MAX_CONCURRENT] ?: 3).coerceIn(1, 5),
            speedLimitKbps = (prefs[Keys.SPEED_LIMIT_KBPS] ?: 0).coerceAtLeast(0),
            wifiOnly = prefs[Keys.WIFI_ONLY] ?: false,
            autoRetry = prefs[Keys.AUTO_RETRY] ?: true,
            themeMode = prefs[Keys.THEME_MODE]?.let {
                runCatching { ThemeMode.valueOf(it) }.getOrDefault(ThemeMode.SYSTEM)
            } ?: ThemeMode.SYSTEM
        )
    }

    suspend fun setDefaultThreads(threads: Int) {
        context.dataStore.edit { it[Keys.DEFAULT_THREADS] = threads.coerceIn(1, 8) }
    }

    suspend fun setMaxConcurrentDownloads(maxConcurrent: Int) {
        context.dataStore.edit { it[Keys.MAX_CONCURRENT] = maxConcurrent.coerceIn(1, 5) }
    }

    suspend fun setSpeedLimitKbps(kbps: Int) {
        context.dataStore.edit { it[Keys.SPEED_LIMIT_KBPS] = kbps.coerceAtLeast(0) }
    }

    suspend fun setWifiOnly(enabled: Boolean) {
        context.dataStore.edit { it[Keys.WIFI_ONLY] = enabled }
    }

    suspend fun setAutoRetry(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_RETRY] = enabled }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }
}
