package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "download_segments",
    foreignKeys = [
        ForeignKey(
            entity = DownloadEntity::class,
            parentColumns = ["id"],
            childColumns = ["downloadId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("downloadId")]
)
data class SegmentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val downloadId: Long,
    val segmentIndex: Int,
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long = 0L,
    val isCompleted: Boolean = false
) {
    val totalLength: Long
        get() = if (endByte >= startByte) (endByte - startByte + 1L) else -1L

    val progressFraction: Float
        get() {
            val len = totalLength
            if (len <= 0L) return if (isCompleted) 1f else 0f
            return (downloadedBytes.toFloat() / len.toFloat()).coerceIn(0f, 1f)
        }
}
