package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadEntity
import com.example.data.local.SegmentEntity
import com.example.data.model.DownloadStatus
import com.example.data.model.FileCategory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `read app name string from context`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Pro Download", appName)
    }

    @Test
    fun `dao inserts and observes download task with segments`() = runTest {
        val dao = db.downloadDao()
        val taskId = dao.insertTask(
            DownloadEntity(
                url = "https://example.com/release.apk",
                resolvedUrl = "https://example.com/release.apk",
                fileName = "release.apk",
                mimeType = "application/vnd.android.package-archive",
                category = FileCategory.APP.name,
                totalBytes = 4_000_000L,
                downloadedBytes = 1_000_000L,
                status = DownloadStatus.PAUSED.name,
                threadCount = 2,
                supportsRanges = true
            )
        )

        dao.insertSegments(
            listOf(
                SegmentEntity(
                    downloadId = taskId,
                    segmentIndex = 0,
                    startByte = 0L,
                    endByte = 1_999_999L,
                    downloadedBytes = 1_000_000L,
                    isCompleted = false
                ),
                SegmentEntity(
                    downloadId = taskId,
                    segmentIndex = 1,
                    startByte = 2_000_000L,
                    endByte = 3_999_999L,
                    downloadedBytes = 0L,
                    isCompleted = false
                )
            )
        )

        val observed = dao.observeAllWithSegments().first()
        assertEquals(1, observed.size)
        val item = observed.first()
        assertEquals("release.apk", item.task.fileName)
        assertEquals(2, item.segments.size)
        assertEquals(25, item.progressPercent)

        val fetched = dao.getByIdWithSegments(taskId)
        assertNotNull(fetched)
        assertEquals(DownloadStatus.PAUSED, fetched?.task?.downloadStatus)
    }
}
