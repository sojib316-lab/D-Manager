package com.example

import com.example.data.model.FileCategory
import com.example.engine.Formatters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FormattersTest {

    @Test
    fun `formatBytes formats bytes kilobytes megabytes and gigabytes`() {
        assertEquals("Unknown", Formatters.formatBytes(-1L))
        assertEquals("512 B", Formatters.formatBytes(512L))
        assertEquals("2.0 KB", Formatters.formatBytes(2048L))
        assertEquals("1.50 MB", Formatters.formatBytes(1572864L))
        assertEquals("1.00 GB", Formatters.formatBytes(1073741824L))
    }

    @Test
    fun `formatSpeed and formatEta produce expected strings`() {
        assertEquals("0 KB/s", Formatters.formatSpeed(0L))
        assertEquals("500.0 KB/s", Formatters.formatSpeed(512_000L))
        assertEquals("2.50 MB/s", Formatters.formatSpeed(2_621_440L))
        assertEquals("--:--", Formatters.formatEta(-1L))
        assertEquals("45s", Formatters.formatEta(45L))
        assertEquals("2m 05s", Formatters.formatEta(125L))
        assertEquals("1h 01m", Formatters.formatEta(3665L))
    }

    @Test
    fun `extractUrlsFromText extracts clean unique http and https urls`() {
        val raw = """
            Mirror 1: https://cdn.example.com/releases/ubuntu.iso.
            Mirror 2: http://mirror.example.org/files/archive.zip,
            Duplicate: https://cdn.example.com/releases/ubuntu.iso
        """.trimIndent()

        val urls = Formatters.extractUrlsFromText(raw)
        assertEquals(
            listOf(
                "https://cdn.example.com/releases/ubuntu.iso",
                "http://mirror.example.org/files/archive.zip"
            ),
            urls
        )
    }

    @Test
    fun `parseContentDispositionFileName handles standard and RFC 5987 headers`() {
        assertEquals(
            "report_2026.pdf",
            Formatters.parseContentDispositionFileName("attachment; filename=\"report_2026.pdf\"")
        )
        assertEquals(
            "my archive.zip",
            Formatters.parseContentDispositionFileName("attachment; filename*=UTF-8''my%20archive.zip")
        )
    }

    @Test
    fun `computeSegmentRanges splits large files evenly across requested threads`() {
        val ranges = Formatters.computeSegmentRanges(totalBytes = 10_000_000L, requestedThreads = 4)
        assertEquals(4, ranges.size)
        assertEquals(0L to 2_499_999L, ranges[0])
        assertEquals(2_500_000L to 4_999_999L, ranges[1])
        assertEquals(5_000_000L to 7_499_999L, ranges[2])
        assertEquals(7_500_000L to 9_999_999L, ranges[3])
    }

    @Test
    fun `computeSegmentRanges falls back to single segment for small files`() {
        val ranges = Formatters.computeSegmentRanges(totalBytes = 64_000L, requestedThreads = 8)
        assertEquals(1, ranges.size)
        assertEquals(0L to 63_999L, ranges[0])
    }

    @Test
    fun `file category inference maps extensions and mime types accurately`() {
        assertEquals(FileCategory.VIDEO, FileCategory.infer("clip.mp4", "video/mp4"))
        assertEquals(FileCategory.ARCHIVE, FileCategory.infer("bundle.tar.gz", "application/gzip"))
        assertEquals(FileCategory.APP, FileCategory.infer("ProDownload.apk", "application/vnd.android.package-archive"))
        assertEquals(FileCategory.DOCUMENT, FileCategory.infer("spec.pdf", "application/pdf"))
        assertTrue(Formatters.isValidHttpUrl("https://example.com/file.zip"))
        assertFalse(Formatters.isValidHttpUrl("ftp://example.com/file.zip"))
    }
}
