# Pro Download Manager

An ADM-inspired, multi-threaded native Android download manager built with **Kotlin**, **Jetpack Compose**, **Material 3**, **OkHttp**, **Room**, and **DataStore**, paired with an automated **GitHub Actions** cloud APK build & delivery pipeline.

---

## Core Features

- **Multi-Threaded Segmented Acceleration (1–8 Threads):** Automatically probes `HEAD` / `Range: bytes=0-0` headers to detect `Accept-Ranges` support, splits large files into concurrent byte-range segments, and writes segments in parallel via `FileChannel` positional I/O.
- **Pause, Resume & Auto-Retry:** Exact per-segment byte progress is persisted in Room SQLite, letting you pause and resume downloads across sessions or recover automatically from transient network drops.
- **Queue & Bandwidth Controls:** Configure max concurrent downloads (`1–5`), global speed caps (`512 KB/s` to `10 MB/s` or unlimited), and `Wi-Fi Only` transfer rules.
- **Live Speed Telemetry:** Real-time aggregate throughput sparkline, per-thread segment breakdown inspector, and background `dataSync` foreground service notifications with a **Pause All** action.
- **Batch Link Grabber & Browser Share Support:** Paste multiple links at once, inspect link metadata before downloading, or share URLs directly from Chrome or any Android app via `ACTION_SEND`.
- **MediaStore & File Vault:** Exports finished files directly to `Downloads/ProDownload` (`MediaStore.Downloads` on Android 10+ and `FileProvider` on Android 8–9) with categorized browsing (`Video`, `Audio`, `Archives`, `Docs`, `Apps`, `Images`, `Other`).

---

## Project Specifications

- **Package / Application ID:** `com.prodownloader.app`
- **Minimum SDK:** `26` (Android 8.0 Oreo)
- **Target / Compile SDK:** `36`
- **Architecture:** MVVM + Repository + Room + DataStore + OkHttp Coroutine Engine

---

## Automated APK Build (GitHub Actions)

The workflow in `.github/workflows/android.yml` automatically:
1. Triggers on every push to `main` or manually via **workflow_dispatch**.
2. Sets up **JDK 17** and the **Android SDK** with Gradle dependency caching.
3. Compiles Kotlin (`./gradlew compileDebugKotlin`) and runs all unit + Robolectric tests (`./gradlew testDebugUnitTest`).
4. Builds the installable APK (`./gradlew assembleDebug`), renames `app/build/outputs/apk/debug/app-debug.apk` to `ProDownloadManager.apk`, and uploads it under artifact **`ProDownloadManager-APK`** (retained for **30 days**).

---

## How to Upload to GitHub & Download Your Installable APK

### 1. Push This Project to GitHub
```bash
git init
git add .
git commit -m "Initial commit: Pro Download Manager"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git
git push -u origin main
```

### 2. Run or Monitor GitHub Actions
- Pushing to `main` starts **Android APK Build & Delivery** automatically.
- To run manually: open your repository on GitHub → **Actions** → **Android APK Build & Delivery** → **Run workflow**.

### 3. Download `ProDownloadManager.apk`
1. Open the finished workflow run under the **Actions** tab.
2. Scroll down to **Artifacts** and click **`ProDownloadManager-APK`**.
3. Extract the downloaded `.zip` file to get **`ProDownloadManager.apk`**.

### 4. Install on Your Android Phone
1. Transfer `ProDownloadManager.apk` to your phone (or download the artifact directly on your phone browser and unzip it).
2. Tap `ProDownloadManager.apk` in your phone's **Files** app.
3. If prompted, enable **Install unknown apps** for your file manager/browser, then tap **Install**.
